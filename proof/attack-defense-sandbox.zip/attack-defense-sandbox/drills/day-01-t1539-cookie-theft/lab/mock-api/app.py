from flask import Flask, request, jsonify, make_response, render_template_string
import uuid
import time

app = Flask(__name__)
app.secret_key = 't1539-lab-secret'

# In-memory session store
sessions = {}

LOGIN_PAGE = '''
<!DOCTYPE html>
<html>
<head><title>Mock Trading Platform</title></head>
<body>
<h1>CapitalSim Trading Platform</h1>
<form method="POST" action="/api/login">
<input type="text" name="username" placeholder="Username" value="trader1"><br>
<input type="password" name="password" placeholder="Password" value="password123"><br>
<button type="submit">Login</button>
</form>
</body>
</html>
'''

@app.route('/')
def index():
    return render_template_string(LOGIN_PAGE)

@app.route('/api/login', methods=['POST'])
def login():
    username = request.form.get('username', 'trader1')
    session_id = str(uuid.uuid4())
    
    sessions[session_id] = {
        'username': username,
        'ip': request.remote_addr,
        'user_agent': request.headers.get('User-Agent', ''),
        'created': time.time()
    }
    
    resp = make_response(jsonify({
        'status': 'success',
        'message': 'Logged in',
        'session_id': session_id
    }))
    
    # VULNERABLE: Missing HTTPOnly, Secure, SameSite flags for demo
    resp.set_cookie('session_id', session_id, httponly=False, secure=False, samesite=None)
    
    return resp

@app.route('/api/portfolio')
def portfolio():
    session_id = request.cookies.get('session_id')
    
    if not session_id or session_id not in sessions:
        return jsonify({'error': 'Unauthorized'}), 401
    
    session = sessions[session_id]
    
    # Basic session binding check (can be toggled)
    current_ip = request.remote_addr
    current_ua = request.headers.get('User-Agent', '')
    
    # Log for detection
    print(f"[ACCESS] session={session_id[:8]}... ip={current_ip} ua={current_ua}")
    
    return jsonify({
        'username': session['username'],
        'balance': 154320.50,
        'positions': [
            {'symbol': 'AAPL', 'qty': 100, 'value': 18500.00},
            {'symbol': 'BTCUSD', 'qty': 2.5, 'value': 87500.00},
            {'symbol': 'EURUSD', 'qty': 50000, 'value': 48320.50}
        ],
        'session_bound_to': session['ip'],
        'current_ip': current_ip
    })

@app.route('/api/trade', methods=['POST'])
def trade():
    session_id = request.cookies.get('session_id')
    
    if not session_id or session_id not in sessions:
        return jsonify({'error': 'Unauthorized'}), 401
    
    data = request.get_json()
    symbol = data.get('symbol', 'UNKNOWN')
    qty = data.get('qty', 0)
    
    return jsonify({
        'status': 'executed',
        'symbol': symbol,
        'qty': qty,
        'price': 185.00,
        'total': qty * 185.00
    })

@app.route('/api/logout', methods=['POST'])
def logout():
    session_id = request.cookies.get('session_id')
    if session_id in sessions:
        del sessions[session_id]
    return jsonify({'status': 'logged_out'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)