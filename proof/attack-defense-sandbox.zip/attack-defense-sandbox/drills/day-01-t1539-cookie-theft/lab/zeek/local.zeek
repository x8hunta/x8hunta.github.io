# T1539 Detection Rules - Minimal

# Load base protocols
@load protocols/conn/known-hosts
@load protocols/conn/known-services
@load tuning/json-logs

# Custom T1539 detection: Monitor for session cookie replay
module T1539;

event http_header(c: connection, is_orig: bool, original_name: string, name: string, value: string)
    {
    if ( name == "COOKIE" && /session_id/ in value )
        {
        print fmt("[T1539.ALERT] Session cookie observed: %s from %s -> %s", value, c$id$orig_h, c$id$resp_h);
        }
    }

event zeek_init()
    {
    print "[T1539] Zeek sensor initialized - monitoring for session cookie theft";
    }