# T1539 — Steal Web Session Cookie

## Metadata
| Field | Value |
|-------|-------|
| MITRE ATT&CK ID | T1539 |
| Tactic | Credential Access |
| Sub-technique | T1539.001 (Web Session Cookie) |
| Sector Focus | Financial Services / Retail Trading |
| Target Proxy | Capital.com Web Platform (simulated) |
| Simulation Date | Day 1 |

---

## 1. Threat Context

Session cookies are the primary session-management mechanism for modern trading platforms. Once authenticated, the browser stores a session identifier (cookie) that is replayed on subsequent requests. If an adversary steals this cookie — via XSS, man-in-the-browser malware, network sniffing on unencrypted channels, or browser extension compromise — they can impersonate the user without knowing the password or bypassing MFA.

**Financial Sector Impact:**
- Unauthorized trades (buy/sell orders)
- Account balance exfiltration
- PII harvesting (KYC documents, bank details)
- Lateral movement into linked payment APIs
- Regulatory breach (FINRA, FCA, PCI-DSS)

---

## 2. Simulation Scope

### In-Scope
- Cookie theft via network sniffing (ARP spoofing in isolated Docker lab)
- Cookie replay using `curl` / Python `requests`
- Detection of anomalous session usage (geo-velocity, user-agent mismatch)
- Remediation: HTTPOnly/Secure/SameSite cookie flags, session binding

### Out-of-Scope
- Live Capital.com production environment (read-only observation only)
- Actual financial transactions
- Credential stuffing (covered under T1110)

---

## 3. Target Environment

```
Docker Lab: t1539-lab
├── victim-trader (Ubuntu + Firefox) — logs into mock trading platform
├── mock-trading-api (Flask app) — serves login page, issues session cookies
├── attacker-kali (Kali Linux) — runs Ettercap/Bettercap for ARP spoofing
└── siem-zeek (Zeek + ELK) — captures network traffic and generates alerts
```

Mock trading API endpoints:
- `POST /api/login` — issues `session_id` cookie
- `GET /api/portfolio` — returns portfolio data (requires valid session)
- `POST /api/trade` — executes trade (requires valid session + CSRF token)

---

## 4. Expected Security Controls

| Control | Expected State | Detection Gap |
|---------|---------------|---------------|
| HTTPS/TLS | Enabled | Cookie theft via passive sniffing blocked |
| HTTPOnly flag | Set on `session_id` | Prevents JavaScript cookie theft (XSS vector) |
| Secure flag | Set on `session_id` | Prevents transmission over HTTP |
| SameSite=Strict | Set on `session_id` | Prevents CSRF / cross-site replay |
| Session binding | IP + User-Agent | Detects replay from different device/location |
| Geo-velocity check | Enabled | Flags impossible travel |
| SIEM correlation | Zeek + ELK | Alerts on duplicate session usage |

---

## 5. Success Criteria

### Offensive (Red Team)
- [ ] Capture session cookie from network traffic in the lab
- [ ] Replay cookie successfully against `/api/portfolio`
- [ ] Determine if cookie replay works from different User-Agent / IP
- [ ] Document if HTTPOnly/Secure/SameSite flags are missing

### Defensive (Blue Team)
- [ ] Zeek generates alert on suspicious ARP activity
- [ ] SIEM detects session replay (same cookie, different source IP)
- [ ] Mock API rejects replayed cookie when binding checks are enabled
- [ ] Document detection latency (time from theft to alert)

---

## 6. Career Alignment Note

This exercise maps to:
- **Threat Hunting:** Session anomaly detection, behavioral analytics
- **Detection Engineering:** Writing Zeek/Suricata rules for credential abuse
- **Incident Response:** Cookie theft investigation playbook
- **Application Security:** Secure cookie configuration review

**Correction (2026-11-08):** A resume bullet here claimed detection latency was reduced "from hours to minutes". It was written before the drill ran. The drill found no detection at all (see 03-debrief.md), and nothing was re-tested. No resume bullet until a re-test measures one. The original text is in git history (commit a263419).

---

## 7. Risk & Safety

- All execution inside Docker network `t1539-lab` (172.31.100.0/24)
- No traffic leaves host
- Mock API uses synthetic data only
- Destructive commands require explicit approval
