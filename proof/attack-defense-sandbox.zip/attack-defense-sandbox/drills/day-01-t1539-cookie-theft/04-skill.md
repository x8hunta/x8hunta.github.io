# Skill: T1539 Session Cookie Theft Simulation

## Metadata
| Field | Value |
|-------|-------|
| Name | t1539-session-cookie-theft |
| Category | purple-team / credential-access |
| Created | Day 1 |
| MITRE ATT&CK | T1539 |

## Trigger Conditions
- Web application uses session cookies for authentication
- Application lacks HttpOnly/Secure/SameSite flags
- Session binding is logged but not enforced
- Network monitoring is container-blind (Docker bridge)

## Quick Start
```bash
cd ~/shadowops/purple-playbooks/finance/T1539-Steal-Web-Session-Cookie/lab
docker compose up -d
curl -X POST http://localhost:5000/api/login -d "username=trader1&password=password123" -c cookies.txt
docker exec attacker-kali bash -c "curl -H 'Cookie: session_id=<STOLEN>' http://172.31.100.10:5000/api/portfolio"
```

## Detection Checklist
- [ ] Cookie flags verified (HttpOnly, Secure, SameSite)
- [ ] Session binding enforced (IP + User-Agent)
- [ ] Network sensor sees container east-west traffic
- [ ] SIEM correlation rule for same-cookie/multi-IP active

## Remediation Quick-Apply
```python
resp.set_cookie('session_id', session_id, httponly=True, secure=True, samesite='Strict', max_age=3600)
```

## References
- `01-definition.md` — Threat model and scope
- `02-simulation.md` — Full execution log
- `03-debrief.md` — Metrics, gaps, and remediation
