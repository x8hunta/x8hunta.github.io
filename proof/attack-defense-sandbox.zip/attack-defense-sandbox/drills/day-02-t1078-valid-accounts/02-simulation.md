# T1078 Simulation Execution Log

## Metadata
| Field | Value |
|-------|-------|
| TTP | T1078 — Valid Accounts |
| Date | Day 2 |
| Environment | Docker lab `lab_purple-lab` (172.31.101.0/24) |
| Status | COMPLETE |

---

## Lab Topology

```
172.31.101.10  t1078-target (FastAPI trading backend) — victim
172.31.101.30  t1078-attacker — red team
Host port map: localhost:5001 → t1078-target:5000
```

Target app features added for T1078:
- Username/password auth with account lockout (5 fails = 15 min lock)
- API key auth (X-API-Key header) with rotation tracking
- Dormant account auto-disable (90 days inactive, checked at login)
- Structured JSON auth logging to `/app/logs/auth.log`

---

## Phase 1: Credential Stuffing

### Attack: trader1
```bash
python3 credential_stuffing.py http://localhost:5001 trader1
```

**Wordlist:** password, 123456, qwerty, admin, letmein, password123, welcome1, trader2024, capital, money

**Result:**
```
[-] FAILED: trader1:password (HTTP 401)
[-] FAILED: trader1:123456 (HTTP 401)
[-] FAILED: trader1:qwerty (HTTP 401)
[-] FAILED: trader1:admin (HTTP 401)
[-] FAILED: trader1:letmein (HTTP 401)
[!] ACCOUNT LOCKED after password: password123
    Response: {'error': 'Account locked. Try again in 899s'}
```

**🔴 RED TEAM PARTIAL:** Lockout triggered before correct password (password123, 6th in list) was reached.
**🟢 BLUE TEAM WIN:** Account lockout control functioned as designed.

### Attack: admin
```bash
python3 credential_stuffing.py http://localhost:5001 admin
```

**Result:** Same pattern — 5 failures triggered lockout before `admin123` (4th in list, but 5th failure fired on the 5th attempt).

**Note:** The lockout increments `failed_attempts` before checking the password. On the 5th failed attempt, the account locks immediately. The 6th attempt (which happened to be the correct password for trader1) hit the lockout screen.

---

## Phase 2: API Key Abuse

### Attack: Leaked Key Usage
```bash
python3 api_key_abuse.py http://localhost:5001
```

**Leaked key:** `cs_live_51HZk2x_sample_leaked_key_t1078` (pre-seeded, 100 days old)

**Results:**
```
[+] GET /api/portfolio -> HTTP 200
    Data: {'balance': 154320.5, 'positions': [...], 'username': 'trader1'}
[+] POST /api/trade -> HTTP 200
    Data: {'price': 185.0, 'qty': 999, 'status': 'executed', 'symbol': 'AAPL', 'total': 184815.0}
[+] POST /api/key -> HTTP 200
    NEW KEY GENERATED: cs_live_f7c6d3e2ffdb4aedaafdcc65ca461c03
[!] Attacker now has a fresh key for long-term access
```

**🔴 RED TEAM WIN:** Leaked API key bypassed username/password auth entirely. Full portfolio exfil, trade execution, and persistence via new key generation — all without ever knowing the password.

### Detection Gap
- No anomaly detection on API key usage from unexpected IP or User-Agent
- No alert on 999-share trade via API key (unusual size)
- No alert on new key generation by an old key (rotation policy violation)

---

## Phase 3: Dormant Account Abuse

### Attack Sequence
```bash
python3 dormant_account.py http://localhost:5001
```

**Step 1:** Admin login → session acquired  
**Step 2:** Reactivate `service_api` → HTTP 200, `was_inactive: false`  
**Step 3:** Attacker login as `service_api` → session acquired, portfolio accessed

**Result:**
```
[+] Admin session: 5de87e39-39c9-4264-a503-e51314fcb234
[+] Reactivation response: HTTP 200
    Data: {'status': 'reactivated', 'username': 'service_api', 'was_inactive': false}
[+] Dormant account session: ba9f2ef4-6a43-4e40-b9b4-e491e8bc6f48
[+] GET /api/portfolio -> HTTP 200
    Data: {'balance': 154320.5, ...}
```

**Note on `was_inactive: false`:** The dormancy check only triggers during login attempts. Since the first action against `service_api` was admin reactivation (which resets `last_login = time.time()`), the account was technically "active" at reactivation time. A proper attack sequence would be: attempt login as dormant user → blocked → admin reactivates → attacker logs in. The simulation demonstrates the post-reactivation abuse vector.

**🔴 RED TEAM WIN:** Admin endpoint used to re-enable a stale service account, which was then used for unauthorized access.

### Detection Gap
- No alert on dormant account reactivation event (`account_reactivated` logged but not alerted)
- No correlation between admin action and subsequent attacker session from same IP

---

## Phase 4: Blue Team Detection Review

### Auth Log Analysis

**Total events captured:** 15

| Event Type | Count | Status |
|------------|-------|--------|
| login_attempt (bad_password) | 8 | warn |
| account_lockout | 2 | alert |
| login_attempt (account_locked) | 2 | warn |
| login_success | 4 | ok |
| portfolio_access | 2 | ok |
| trade_executed | 1 | ok |
| api_key_created | 1 | ok |
| account_reactivated | 1 | alert |

### Key Observations

**Credential Stuffing Detection:**
- 5 failed attempts in <3 seconds from same IP → lockout triggered → logged as `account_lockout`
- **Gap:** No real-time alert. Lockout is reactive, not proactive.
- **Gap:** No rate-limiting on the IP itself — attacker can pivot to other usernames immediately.

**API Key Abuse Detection:**
- Leaked key was 100 days old (beyond 90-day rotation policy) but still accepted
- Key usage logged as normal `portfolio_access` with `method: api_key`
- **Gap:** No detection of old key usage, no geo/UA anomaly check, no trade size validation

**Dormant Account Detection:**
- `account_reactivated` logged with `status: alert` → good logging
- **Gap:** No automated alert or approval workflow for reactivation
- **Gap:** Admin endpoint lacks MFA or secondary approval

---

## Success Criteria Checklist

### Red Team
- [x] Attempt credential stuffing against login endpoint — blocked by lockout
- [x] Access /portfolio using leaked API key without password — SUCCESS
- [x] Execute trades via leaked API key — SUCCESS
- [x] Generate fresh API key for persistence — SUCCESS
- [x] Reactivate dormant account and authenticate — SUCCESS

### Blue Team
- [x] Detect spike in failed auth attempts — LOGGED (account_lockout events)
- [ ] Detect API key usage from unexpected source — NO DETECTION
- [ ] Detect dormant account re-enablement in real-time — LOGGED BUT NOT ALERTED
- [ ] Measure detection latency — INFINITE — no alerts generated

---

## Artifacts

| Artifact | Location |
|----------|----------|
| Lab compose file | `lab/docker-compose.yml` |
| Mock API source | `lab/mock-api/app.py` |
| Attacker scripts | `lab/attacker/{credential_stuffing,api_key_abuse,dormant_account}.py` |
| Auth logs | `lab/logs/auth.log` |
| Leaked API key | `cs_live_51HZk2x_sample_leaked_key_t1078` |
| Attacker-generated key | `cs_live_f7c6d3e2ffdb4aedaafdcc65ca461c03` |
