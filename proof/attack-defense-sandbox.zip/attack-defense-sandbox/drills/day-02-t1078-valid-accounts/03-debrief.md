# T1078 Debrief — Metrics, Tuning & Executive Summary

## Metadata
| Field | Value |
|-------|-------|
| TTP | T1078 — Valid Accounts |
| Simulation Date | Day 2 |
| Status | COMPLETE |

---

## 1. Quantified Metrics

| Metric | Value | Assessment |
|--------|-------|------------|
| Dwell Time (API key abuse) | Infinite — undetected | ❌ FAIL |
| Dwell Time (dormant account) | Infinite — undetected | ❌ FAIL |
| Detection Latency (credential stuffing) | 0s (lockout triggered) but no alert | ⚠️ PARTIAL |
| MTTR | N/A — no alerts generated | ❌ FAIL |
| False Positive Rate | Not measured — no alerting rules exist | ❌ FAIL |
| Time to Account Lockout | ~3 seconds (5 attempts) | ✅ PASS |
| API Key Abuse Duration | ~5 seconds — full portfolio + trade + new key | ❌ FAIL |

---

## 2. Control Effectiveness Matrix

| Control | Expected | Actual | Gap |
|---------|----------|--------|-----|
| Account lockout (5 fails/15 min) | Block brute force | ✅ Blocked both sprays | Reactive only — no IP rate limit |
| API key rotation (90-day policy) | Expire old keys | ❌ 100-day key still accepted | Policy not enforced in code |
| Dormant account disable | Block stale accounts | ⚠️ Disabled on login, but admin can bypass without alert | No reactivation approval workflow |
| Auth logging | All events captured | ✅ 15 events logged | Logging ≠ alerting |
| Geo/IP anomaly | Detect impossible travel | ❌ Not implemented | Missing control entirely |

---

## 3. Executive Summary

**Risk Exposure:**
- A single leaked API key granted unrestricted access to portfolio data and trade execution capabilities. No password, no MFA, no session binding was required.
- A dormant service account — inactive for 120 days — was reactivated via a single admin API call and immediately used for unauthorized access. No approval, no notification, no audit trail review.

**Compliance Gaps:**
- **PCI-DSS 8.2** — Strong authentication not enforced for API keys. No MFA on API endpoints.
- **FINRA Rule 3110** — Supervisory system failed to detect or alert on account reactivation and anomalous API usage.
- **SOC 2 CC6.1** — Logical access controls not operating effectively; API keys lack expiration enforcement.

**Estimated Impact (Synthetic):**
- Unauthorized trade: 999 shares AAPL @ $185 = $184,815 notional exposure
- Portfolio data exposed: $154,320 balance + full position detail
- If attacker maintained access via rotated API key: indefinite dwell time

---

## 4. Tuning Recommendations

### 4.1 Detection Rules

**Rule 1: API Key Age Violation**
```python
# Reject API keys older than rotation policy
key_age_days = (now - api_keys[key]['created']) / 86400
if key_age_days > 90:
    log_event('api_key_expired', ...)
    return jsonify({'error': 'API key expired. Rotate your key.'}), 401
```

**Rule 2: Impossible Travel / New IP Alert**
```python
# Alert on API key or session used from new IP
if last_ip and current_ip != last_ip:
    log_event('auth_anomaly_ip', status='alert', ...)
    # Optionally require re-auth for high-risk endpoints
```

**Rule 3: Dormant Account Reactivation Alert**
```python
# Require secondary approval for reactivating accounts idle > 90 days
if days_inactive > 90:
    require_mfa_or_approval(admin_session)
    send_alert('dormant_account_reactivated', ...)
```

**Rule 4: Credential Stuffing Detection**
```python
# Alert on >3 failed logins from same IP in 60 seconds
# (Already have lockout; add IP-level rate limiting + alert)
```

### 4.2 Policy Changes

| Policy | Current | Recommended |
|--------|---------|-------------|
| API key rotation | 90-day guideline | Enforced expiration in auth middleware |
| Dormant accounts | Auto-disable at login | Auto-disable + admin reactivation requires MFA + ticket |
| Trade size limits | None | Configurable per API key / user role |
| Alerting | Log only | Real-time webhooks to SIEM/Slack/PagerDuty |

### 4.3 Remediation Code

File: `lab/mock-api/security_middleware.py` (recommended addition)
```python
def check_api_key_health(key):
    data = api_keys.get(key)
    if not data:
        return False, 'Invalid key'
    age = (time.time() - data['created']) / 86400
    if age > 90:
        return False, f'Key expired ({age:.0f} days)'
    return True, 'OK'

def alert_on_anomaly(username, current_ip, event):
    last = user_last_ips.get(username)
    if last and last != current_ip:
        log_event(event, username=username, status='alert',
                  details={'last_ip': last, 'current_ip': current_ip})
    user_last_ips[username] = current_ip
```

---

## 5. Career Alignment Note

This exercise maps to:
- **Detection Engineering:** Writing behavioral rules for auth anomalies, API key lifecycle, and dormant account events
- **Threat Hunting:** Identifying valid-account abuse via log analysis and statistical anomaly detection
- **Application Security:** Designing secure auth flows with enforced key rotation and MFA-gated admin actions
- **GRC / Compliance:** Mapping technical controls to PCI-DSS, FINRA, and SOC 2 requirements

**Correction (2026-11-08):** A resume bullet here claimed remediation "reduced mean-time-to-detection from unmonitored to <5 minutes". At the time of this debrief no fix had been built or re-tested, so that was a target. The measured result is in 06-post-tuning.md. The original text is in git history (commit a263419).

---

## 6. Next Steps

- [ ] Implement `security_middleware.py` in target app
- [ ] Write pytest tests for each new control
- [ ] Re-run T1078 simulation to validate controls
- [ ] Promote validated playbook to Hermes skill (Phase 5)
