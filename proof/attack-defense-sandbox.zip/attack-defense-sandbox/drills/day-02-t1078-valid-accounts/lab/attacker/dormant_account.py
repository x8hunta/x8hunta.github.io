#!/usr/bin/env python3
"""
T1078 Valid Accounts — Dormant Account Abuse Simulation
1. Admin reactivates a dormant service account
2. Attacker uses the reactivated account's credentials
"""
import requests
import sys

TARGET = sys.argv[1] if len(sys.argv) > 1 else "http://mock-trading-api:5000"
ADMIN_USER = "admin"
ADMIN_PASS = "admin123"
DORMANT_USER = "service_api"
DORMANT_PASS = "ServicePass99!"

def admin_reactivate():
    print(f"[*] Step 1: Admin login to get session")
    r = requests.post(f"{TARGET}/api/login", data={
        "username": ADMIN_USER,
        "password": ADMIN_PASS
    }, timeout=5)

    if r.status_code != 200:
        print(f"[!] Admin login failed: {r.text}")
        return None

    session = r.cookies.get("session_id")
    print(f"[+] Admin session: {session}")

    print(f"[*] Step 2: Reactivating dormant account '{DORMANT_USER}'")
    r2 = requests.post(f"{TARGET}/api/admin/reactivate",
                       cookies={"session_id": session},
                       json={"username": DORMANT_USER},
                       timeout=5)
    print(f"[+] Reactivation response: HTTP {r2.status_code}")
    if r2.status_code == 200:
        print(f"    Data: {r2.json()}")

    return session

def attacker_use_dormant():
    print(f"\n[*] Step 3: Attacker logs in as reactivated '{DORMANT_USER}'")
    r = requests.post(f"{TARGET}/api/login", data={
        "username": DORMANT_USER,
        "password": DORMANT_PASS
    }, timeout=5)

    if r.status_code != 200:
        print(f"[!] Dormant account login failed: {r.text}")
        return

    session = r.cookies.get("session_id")
    print(f"[+] Dormant account session: {session}")

    r2 = requests.get(f"{TARGET}/api/portfolio",
                      cookies={"session_id": session},
                      timeout=5)
    print(f"[+] GET /api/portfolio -> HTTP {r2.status_code}")
    if r2.status_code == 200:
        print(f"    Data: {r2.json()}")

if __name__ == "__main__":
    admin_reactivate()
    attacker_use_dormant()
