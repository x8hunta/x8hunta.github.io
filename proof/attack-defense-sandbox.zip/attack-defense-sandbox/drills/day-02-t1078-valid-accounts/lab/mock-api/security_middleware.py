"""
T1078 Blue Team Security Middleware
Enforces API key expiration, IP/UA anomaly detection, IP rate limiting,
and dormant account reactivation gating.
"""

import time
from collections import defaultdict

# === Config ===
API_KEY_MAX_AGE_DAYS = 90
RATE_LIMIT_WINDOW = 60      # seconds
RATE_LIMIT_MAX = 3          # attempts per window per IP
DORMANT_THRESHOLD_DAYS = 90

# === State ===
ip_login_attempts = defaultdict(list)   # ip -> list of timestamps
user_last_ips = {}                      # username -> last seen IP
user_last_uas = {}                      # username -> last seen User-Agent


def check_api_key_health(api_keys, key):
    """Reject expired or unknown API keys."""
    data = api_keys.get(key)
    if not data:
        return False, "Invalid API key"

    age_days = (time.time() - data["created"]) / 86400
    if age_days > API_KEY_MAX_AGE_DAYS:
        return False, f"API key expired ({age_days:.0f} days old). Rotate your key."

    return True, "OK"


def check_ip_rate_limit(ip):
    """Block + alert if same IP exceeds threshold in window."""
    now = time.time()
    attempts = ip_login_attempts[ip]

    # Prune old attempts
    attempts[:] = [t for t in attempts if now - t < RATE_LIMIT_WINDOW]

    if len(attempts) >= RATE_LIMIT_MAX:
        return False, f"Rate limit exceeded: {len(attempts)} attempts in {RATE_LIMIT_WINDOW}s"

    attempts.append(now)
    return True, "OK"


def check_auth_anomaly(username, current_ip, current_ua, log_event):
    """Alert on IP or UA change for a given user. Returns list of triggered alerts."""
    last_ip = user_last_ips.get(username)
    last_ua = user_last_uas.get(username)
    alerts = []

    if last_ip and last_ip != current_ip:
        log_event(
            "auth_anomaly_ip",
            username=username,
            status="alert",
            details={"last_ip": last_ip, "current_ip": current_ip},
        )
        alerts.append("ip_change")

    if last_ua and last_ua != current_ua:
        log_event(
            "auth_anomaly_ua",
            username=username,
            status="alert",
            details={"last_ua": last_ua, "current_ua": current_ua},
        )
        alerts.append("ua_change")

    user_last_ips[username] = current_ip
    user_last_uas[username] = current_ua
    return alerts


def reactivate_account(users, username, admin_session, log_event, require_mfa=False):
    """Re-enable dormant account with approval + alert."""
    user = users.get(username)
    if not user:
        return False, "User not found"

    days_inactive = (time.time() - user["last_login"]) / 86400
    was_dormant = days_inactive > DORMANT_THRESHOLD_DAYS

    if was_dormant and require_mfa:
        if not admin_session.get("mfa_verified"):
            return False, "MFA required to reactivate dormant account"

    user["active"] = True
    user["last_login"] = time.time()

    log_event(
        "account_reactivated",
        username=username,
        status="alert",
        details={
            "by_admin": admin_session.get("username"),
            "was_dormant": was_dormant,
            "days_inactive": round(days_inactive, 1),
        },
    )
    return True, {"status": "reactivated", "was_dormant": was_dormant}


def reset_state():
    """Reset all middleware state — for testing only."""
    ip_login_attempts.clear()
    user_last_ips.clear()
    user_last_uas.clear()
