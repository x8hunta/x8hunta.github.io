from flask import Flask, request, jsonify, make_response, render_template_string
import uuid
import time
import json
import os
from datetime import datetime

from security_middleware import (
    check_api_key_health,
    check_ip_rate_limit,
    check_auth_anomaly,
    reactivate_account as sm_reactivate,
)

app = Flask(__name__)
app.secret_key = 't1078-lab-secret'

# In-memory stores
sessions = {}
api_keys = {}
users = {
    'trader1': {
        'password': 'password123',
        'active': True,
        'last_login': time.time(),
        'failed_attempts': 0,
        'locked_until': 0,
        'role': 'trader'
    },
    'trader2': {
        'password': 'qwerty2024',
        'active': True,
        'last_login': time.time() - 86400 * 10,  # 10 days ago
        'failed_attempts': 0,
        'locked_until': 0,
        'role': 'trader'
    },
    'service_api': {
        'password': 'ServicePass99!',
        'active': True,
        'last_login': time.time() - 86400 * 120,  # 120 days ago -> dormant
        'failed_attempts': 0,
        'locked_until': 0,
        'role': 'service'
    },
    'admin': {
        'password': 'admin123',
        'active': True,
        'last_login': time.time(),
        'failed_attempts': 0,
        'locked_until': 0,
        'role': 'admin'
    }
}

# Pre-seed a leaked API key for trader1
LEAKED_API_KEY = 'cs_live_51HZk2x_sample_leaked_key_t1078'
api_keys[LEAKED_API_KEY] = {
    'username': 'trader1',
    'created': time.time() - 86400 * 100,  # 100 days old (beyond rotation)
    'last_used': time.time() - 86400 * 5,
    'ip_whitelist': None
}

LOG_FILE = '/app/logs/auth.log'
os.makedirs('/app/logs', exist_ok=True)


def log_event(event_type, username=None, ip=None, details=None, status='info'):
    entry = {
        'timestamp': datetime.utcnow().isoformat() + 'Z',
        'event': event_type,
        'username': username,
        'ip': ip or request.remote_addr,
        'user_agent': request.headers.get('User-Agent', ''),
        'status': status,
        'details': details or {}
    }
    with open(LOG_FILE, 'a') as f:
        f.write(json.dumps(entry) + '\n')
    print(f"[{status.upper()}] {event_type} user={username} ip={entry['ip']}")


LOGIN_PAGE = '''
<!DOCTYPE html>
<html>
<head><title>Mock Trading Platform</title></head>
<body>
<h1>CapitalSim Trading Platform</h1>
<form method="POST" action="/api/login">
<input type="text" name="username" placeholder="Username"><br>
<input type="password" name="password" placeholder="Password"><br>
<button type="submit">Login</button>
</form>
</body>
</html>
'''


@app.route('/')
def index():
    return render_template_string(LOGIN_PAGE)


@app.route('/api/login', methods=['POST'])
def login():
    username = request.form.get('username') or request.json.get('username', '')
    password = request.form.get('password') or request.json.get('password', '')
    ip = request.remote_addr

    # === BLUE TEAM: IP rate limiting ===
    ok, msg = check_ip_rate_limit(ip)
    if not ok:
        log_event('ip_rate_limit', username=username, ip=ip,
                  details={'reason': msg}, status='alert')
        return jsonify({'error': msg}), 429

    if username not in users:
        log_event('login_attempt', username=username, ip=ip,
                  details={'reason': 'unknown_user'}, status='warn')
        return jsonify({'error': 'Invalid credentials'}), 401

    user = users[username]

    # Check dormant (inactive > 90 days)
    days_inactive = (time.time() - user['last_login']) / 86400
    if days_inactive > 90 and user['role'] != 'admin':
        user['active'] = False

    if not user['active']:
        log_event('login_attempt', username=username, ip=ip,
                  details={'reason': 'account_disabled', 'days_inactive': round(days_inactive, 1)},
                  status='warn')
        return jsonify({'error': 'Account disabled. Contact admin.'}), 403

    # Check lockout
    if user['locked_until'] > time.time():
        remaining = int(user['locked_until'] - time.time())
        log_event('login_attempt', username=username, ip=ip,
                  details={'reason': 'account_locked', 'remaining_sec': remaining}, status='warn')
        return jsonify({'error': f'Account locked. Try again in {remaining}s'}), 429

    # Validate password
    if user['password'] != password:
        user['failed_attempts'] += 1
        if user['failed_attempts'] >= 5:
            user['locked_until'] = time.time() + 900  # 15 min lockout
            log_event('account_lockout', username=username, ip=ip,
                      details={'failed_attempts': user['failed_attempts']}, status='alert')
        else:
            log_event('login_attempt', username=username, ip=ip,
                      details={'reason': 'bad_password', 'failed_attempts': user['failed_attempts']},
                      status='warn')
        return jsonify({'error': 'Invalid credentials'}), 401

    # Success
    user['failed_attempts'] = 0
    user['last_login'] = time.time()
    session_id = str(uuid.uuid4())
    sessions[session_id] = {
        'username': username,
        'ip': ip,
        'user_agent': request.headers.get('User-Agent', ''),
        'created': time.time()
    }

    log_event('login_success', username=username, ip=ip,
              details={'session_id': session_id[:8], 'role': user['role']}, status='ok')

    # === BLUE TEAM: Anomaly detection ===
    check_auth_anomaly(
        username, ip, request.headers.get('User-Agent', ''), log_event
    )

    resp = make_response(jsonify({
        'status': 'success',
        'message': 'Logged in',
        'session_id': session_id,
        'role': user['role']
    }))
    resp.set_cookie('session_id', session_id, httponly=True, secure=False, samesite='Lax')
    return resp


@app.route('/api/key', methods=['POST'])
def generate_api_key():
    """Generate API key for authenticated user."""
    auth_header = request.headers.get('Authorization', '')
    api_key = request.headers.get('X-API-Key', '')
    username = None

    # Try session auth
    session_id = request.cookies.get('session_id')
    if session_id and session_id in sessions:
        username = sessions[session_id]['username']
    # Try API key auth
    elif api_key and api_key in api_keys:
        username = api_keys[api_key]['username']
        api_keys[api_key]['last_used'] = time.time()
    # Try basic auth
    elif auth_header.startswith('Basic '):
        import base64
        creds = base64.b64decode(auth_header[6:]).decode().split(':')
        if len(creds) == 2 and creds[0] in users and users[creds[0]]['password'] == creds[1]:
            username = creds[0]

    if not username:
        return jsonify({'error': 'Unauthorized'}), 401

    new_key = 'cs_live_' + str(uuid.uuid4()).replace('-', '')
    api_keys[new_key] = {
        'username': username,
        'created': time.time(),
        'last_used': time.time(),
        'ip_whitelist': None
    }
    log_event('api_key_created', username=username, ip=request.remote_addr,
              details={'key_prefix': new_key[:16]}, status='ok')
    return jsonify({'api_key': new_key, 'username': username})


@app.route('/api/portfolio')
def portfolio():
    username = _get_auth_user()
    if not username:
        return jsonify({'error': 'Unauthorized'}), 401

    log_event('portfolio_access', username=username, ip=request.remote_addr,
              details={'method': _auth_method()}, status='ok')

    return jsonify({
        'username': username,
        'balance': 154320.50,
        'positions': [
            {'symbol': 'AAPL', 'qty': 100, 'value': 18500.00},
            {'symbol': 'BTCUSD', 'qty': 2.5, 'value': 87500.00},
            {'symbol': 'EURUSD', 'qty': 50000, 'value': 48320.50}
        ]
    })


@app.route('/api/trade', methods=['POST'])
def trade():
    username = _get_auth_user()
    if not username:
        return jsonify({'error': 'Unauthorized'}), 401

    data = request.get_json()
    symbol = data.get('symbol', 'UNKNOWN')
    qty = data.get('qty', 0)

    log_event('trade_executed', username=username, ip=request.remote_addr,
              details={'symbol': symbol, 'qty': qty}, status='ok')

    return jsonify({
        'status': 'executed',
        'symbol': symbol,
        'qty': qty,
        'price': 185.00,
        'total': qty * 185.00
    })


@app.route('/api/admin/reactivate', methods=['POST'])
def reactivate_account():
    """Admin endpoint to re-enable dormant accounts."""
    session_id = request.cookies.get('session_id')
    if not session_id or session_id not in sessions:
        return jsonify({'error': 'Unauthorized'}), 401

    admin_user = sessions[session_id]['username']
    if users[admin_user]['role'] != 'admin':
        log_event('unauthorized_admin', username=admin_user, ip=request.remote_addr,
                  details={'endpoint': '/api/admin/reactivate'}, status='alert')
        return jsonify({'error': 'Admin required'}), 403

    target = request.json.get('username')
    if target not in users:
        return jsonify({'error': 'User not found'}), 404

    # === BLUE TEAM: Dormant reactivation gate ===
    admin_session = sessions[session_id]
    ok, result = sm_reactivate(
        users, target, admin_session, log_event, require_mfa=False
    )
    if not ok:
        return jsonify({'error': result}), 403

    return jsonify(result)


@app.route('/api/admin/users')
def list_users():
    """Admin endpoint to view user status."""
    session_id = request.cookies.get('session_id')
    if not session_id or session_id not in sessions:
        return jsonify({'error': 'Unauthorized'}), 401

    admin_user = sessions[session_id]['username']
    if users[admin_user]['role'] != 'admin':
        return jsonify({'error': 'Admin required'}), 403

    summary = {}
    for u, data in users.items():
        summary[u] = {
            'active': data['active'],
            'role': data['role'],
            'last_login': data['last_login'],
            'failed_attempts': data['failed_attempts'],
            'locked_until': data['locked_until']
        }
    return jsonify(summary)


@app.route('/api/logout', methods=['POST'])
def logout():
    session_id = request.cookies.get('session_id')
    if session_id in sessions:
        log_event('logout', username=sessions[session_id]['username'],
                  ip=request.remote_addr, status='ok')
        del sessions[session_id]
    return jsonify({'status': 'logged_out'})


def _get_auth_user():
    session_id = request.cookies.get('session_id')
    if session_id and session_id in sessions:
        return sessions[session_id]['username']
    api_key = request.headers.get('X-API-Key', '')
    if api_key:
        # === BLUE TEAM: API key health check ===
        ok, msg = check_api_key_health(api_keys, api_key)
        if not ok:
            log_event('api_key_rejected', username=None, ip=request.remote_addr,
                      details={'reason': msg, 'key_prefix': api_key[:16]}, status='alert')
            return None
        api_keys[api_key]['last_used'] = time.time()
        return api_keys[api_key]['username']
    return None


def _auth_method():
    if request.cookies.get('session_id'):
        return 'session_cookie'
    if request.headers.get('X-API-Key'):
        return 'api_key'
    return 'none'


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
