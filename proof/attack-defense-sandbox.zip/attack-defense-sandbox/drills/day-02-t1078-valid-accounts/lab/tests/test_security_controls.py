"""
pytest suite for T1078 blue team security middleware.
Run: python -m pytest tests/ -v
"""
import pytest
import time
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "mock-api"))

from security_middleware import (
    check_api_key_health,
    check_ip_rate_limit,
    check_auth_anomaly,
    reactivate_account,
    reset_state,
)


class TestApiKeyHealth:
    def test_valid_key(self):
        keys = {"k1": {"created": time.time()}}
        ok, msg = check_api_key_health(keys, "k1")
        assert ok is True
        assert msg == "OK"

    def test_expired_key(self):
        keys = {"k1": {"created": time.time() - 86400 * 100}}
        ok, msg = check_api_key_health(keys, "k1")
        assert ok is False
        assert "expired" in msg
        assert "100" in msg

    def test_unknown_key(self):
        ok, msg = check_api_key_health({}, "k1")
        assert ok is False
        assert "Invalid" in msg


class TestIpRateLimit:
    def setup_method(self):
        reset_state()

    def test_under_limit(self):
        ok, msg = check_ip_rate_limit("1.2.3.4")
        assert ok is True
        ok, msg = check_ip_rate_limit("1.2.3.4")
        assert ok is True
        ok, msg = check_ip_rate_limit("1.2.3.4")
        assert ok is True

    def test_over_limit(self):
        ok, msg = check_ip_rate_limit("1.2.3.5")
        assert ok is True
        ok, msg = check_ip_rate_limit("1.2.3.5")
        assert ok is True
        ok, msg = check_ip_rate_limit("1.2.3.5")
        assert ok is True
        ok, msg = check_ip_rate_limit("1.2.3.5")
        assert ok is False
        assert "Rate limit" in msg

    def test_different_ips_independent(self):
        ok, msg = check_ip_rate_limit("1.1.1.1")
        assert ok is True
        ok, msg = check_ip_rate_limit("2.2.2.2")
        assert ok is True


class TestAuthAnomaly:
    def setup_method(self):
        reset_state()

    def test_first_seen_no_alert(self):
        log_calls = []

        def fake_log(event, **kwargs):
            log_calls.append((event, kwargs))

        alerts = check_auth_anomaly("u1", "1.1.1.1", "Mozilla/5.0", fake_log)
        assert alerts == []
        assert len(log_calls) == 0

    def test_ip_change_triggers_alert(self):
        log_calls = []

        def fake_log(event, **kwargs):
            log_calls.append((event, kwargs))

        check_auth_anomaly("u1", "1.1.1.1", "Mozilla/5.0", fake_log)
        alerts = check_auth_anomaly("u1", "2.2.2.2", "Mozilla/5.0", fake_log)

        assert "ip_change" in alerts
        assert log_calls[-1][0] == "auth_anomaly_ip"
        assert log_calls[-1][1]["status"] == "alert"

    def test_ua_change_triggers_alert(self):
        log_calls = []

        def fake_log(event, **kwargs):
            log_calls.append((event, kwargs))

        check_auth_anomaly("u1", "1.1.1.1", "Mozilla/5.0", fake_log)
        alerts = check_auth_anomaly("u1", "1.1.1.1", "curl/8.0", fake_log)

        assert "ua_change" in alerts
        assert log_calls[-1][0] == "auth_anomaly_ua"


class TestReactivateAccount:
    def test_reactivate_active_user(self):
        log_calls = []

        def fake_log(event, **kwargs):
            log_calls.append((event, kwargs))

        users = {
            "trader1": {
                "active": True,
                "last_login": time.time(),
            }
        }
        admin = {"username": "admin"}

        ok, result = reactivate_account(users, "trader1", admin, fake_log)
        assert ok is True
        assert result["was_dormant"] is False
        assert log_calls[-1][0] == "account_reactivated"

    def test_reactivate_dormant_user(self):
        log_calls = []

        def fake_log(event, **kwargs):
            log_calls.append((event, kwargs))

        users = {
            "service_api": {
                "active": False,
                "last_login": time.time() - 86400 * 120,
            }
        }
        admin = {"username": "admin"}

        ok, result = reactivate_account(users, "service_api", admin, fake_log)
        assert ok is True
        assert result["was_dormant"] is True
        assert users["service_api"]["active"] is True
        assert log_calls[-1][1]["details"]["was_dormant"] is True

    def test_reactivate_unknown_user(self):
        ok, msg = reactivate_account({}, "nobody", {}, lambda **kw: None)
        assert ok is False
        assert "not found" in msg

    def test_reactivate_requires_mfa_when_dormant(self):
        log_calls = []

        def fake_log(event, **kwargs):
            log_calls.append((event, kwargs))

        users = {
            "service_api": {
                "active": False,
                "last_login": time.time() - 86400 * 120,
            }
        }
        admin = {"username": "admin", "mfa_verified": False}

        ok, msg = reactivate_account(
            users, "service_api", admin, fake_log, require_mfa=True
        )
        assert ok is False
        assert "MFA required" in msg
