# T1078 Blue Team Tuning Plan — Implementation Roadmap

> Derived from 03-debrief.md detection gaps. Each control maps to a measurable outcome.

---

## Overview

| Gap | Control to Build | Priority | Effort |
|-----|------------------|----------|--------|
| API key abuse undetected | Key age enforcement + IP anomaly detection | P1 | Medium |
| Dormant account reactivation unalerted | Admin action approval gate + real-time alert | P1 | Low |
| Credential stuffing no proactive alert | IP-level rate limiting + alert on threshold | P2 | Low |
| Logging without alerting | Webhook alert pipeline (Slack/SIEM) | P1 | Low |

---

## Phase 1: Security Middleware (Core Enforcement)

**File:** `lab/mock-api/security_middleware.py`
**Goal:** Enforce controls in the auth pipeline before any protected endpoint is reached.

### 1.1 API Key Health Check

```python
import time
from flask import jsonify

API_KEY_MAX_AGE_DAYS = 90


def check_api_key_health(api_keys, key):
    """Reject expired or unknown API keys."""
    data = api_keys.get(key)
    if not data:
        return False, "Invalid API key"

    age_days = (time.time() - data["created"]) / 86400
    if age_days > API_KEY_MAX_AGE_DAYS:
        return False, f"API key expired ({age_days:.0f} days old). Rotate your key."

    return True, "OK"
```

**Integration point:** Wrap `_get_auth_user()` in `app.py` — if `X-API-Key` header present, run `check_api_key_health()` before accepting.

**Test:**
```bash
# Pre-seeded leaked key is 100 days old — should now return 401
curl -s -H "X-API-Key: cs_live_51HZk2x_sample_leaked_key_t1078" \
  http://localhost:5001/api/portfolio
# Expected: {"error": "API key expired (100 days old). Rotate your key."}
```

---

### 1.2 IP / User-Agent Anomaly Detection

```python
user_last_ips = {}       # username -> last seen IP
user_last_uas = {}       # username -> last seen User-Agent


def check_auth_anomaly(username, current_ip, current_ua, log_event):
    """Alert on IP or UA change for a given user."""
    last_ip = user_last_ips.get(username)
    last_ua = user_last_uas.get(username)
    alerts = []

    if last_ip and last_ip != current_ip:
        log_event(
            "auth_anomaly_ip",
            username=username,
            status="alert",
            details={"last_ip": last_ip, "current_ip": current_ip},
        )
        alerts.append("ip_change")

    if last_ua and last_ua != current_ua:
        log_event(
            "auth_anomaly_ua",
            username=username,
            status="alert",
            details={"last_ua": last_ua, "current_ua": current_ua},
        )
        alerts.append("ua_change")

    user_last_ips[username] = current_ip
    user_last_ua[username] = current_ua
    return alerts
```

**Integration point:** Call inside every successful auth path (`login_success`, `portfolio_access` via API key, `trade_executed`).

**Test:**
```bash
# Step 1: Login as trader1 from localhost
# Step 2: Replay API key from a different IP (attacker container)
# Expected: `auth_anomaly_ip` alert in auth.log
```

---

### 1.3 IP-Level Rate Limiting (Credential Stuffing Detection)

```python
from collections import defaultdict
import time

ip_login_attempts = defaultdict(list)  # ip -> list of timestamps

RATE_LIMIT_WINDOW = 60   # seconds
RATE_LIMIT_MAX = 3       # attempts per window


def check_ip_rate_limit(ip):
    """Block + alert if same IP exceeds threshold in window."""
    now = time.time()
    attempts = ip_login_attempts[ip]

    # Prune old attempts
    attempts[:] = [t for t in attempts if now - t < RATE_LIMIT_WINDOW]

    if len(attempts) >= RATE_LIMIT_MAX:
        return False, f"Rate limit exceeded: {len(attempts)} attempts in {RATE_LIMIT_WINDOW}s"

    attempts.append(now)
    return True, "OK"
```

**Integration point:** Call at the top of `/api/login` before any password check.

**Test:**
```bash
# 4 rapid login attempts from same IP
for i in 1 2 3 4; do
  curl -s -X POST http://localhost:5001/api/login -d "username=trader1&password=wrong"
done
# Expected: 4th attempt returns 429 + `ip_rate_limit` alert in auth.log
```

---

### 1.4 Dormant Account Reactivation Gate

```python
DORMANT_THRESHOLD_DAYS = 90


def reactivate_account(users, username, admin_session, log_event, require_mfa=False):
    """Re-enable dormant account with approval + alert."""
    user = users.get(username)
    if not user:
        return False, "User not found"

    days_inactive = (time.time() - user["last_login"]) / 86400
    was_dormant = days_inactive > DORMANT_THRESHOLD_DAYS

    if was_dormant and require_mfa:
        # In production: redirect to MFA challenge or require ticket ID
        if not admin_session.get("mfa_verified"):
            return False, "MFA required to reactivate dormant account"

    user["active"] = True
    user["last_login"] = time.time()

    log_event(
        "account_reactivated",
        username=username,
        status="alert",
        details={"by_admin": admin_session.get("username"), "was_dormant": was_dormant, "days_inactive": round(days_inactive, 1)},
    )
    return True, {"status": "reactivated", "was_dormant": was_dormant}
```

**Integration point:** Replace the raw reactivation logic in `/api/admin/reactivate`.

**Test:**
```bash
# Reactivate service_api (120 days idle) — should log alert with was_dormant=true
# Reactivate trader1 (active) — should log with was_dormant=false
```

---

## Phase 2: Alert Pipeline (Log → Webhook)

**File:** `lab/mock-api/alert_pipeline.py`
**Goal:** Turn log events into real-time notifications.

### 2.1 Webhook Dispatcher

```python
import json
import urllib.request

WEBHOOK_URL = "http://siem-observer:5000/alerts"  # or Slack/PagerDuty URL


def send_alert(event_entry):
    """POST alert to webhook endpoint."""
    if event_entry.get("status") not in ("alert", "warn"):
        return  # Only alert-worthy events

    payload = json.dumps(event_entry).encode("utf-8")
    req = urllib.request.Request(
        WEBHOOK_URL,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        urllib.request.urlopen(req, timeout=3)
    except Exception as e:
        print(f"[ALERT PIPELINE] Failed to dispatch: {e}")
```

**Integration point:** Call `send_alert()` inside `log_event()` whenever `status in ("alert", "warn")`.

**Test:**
```bash
# Trigger any alert condition (e.g., account lockout)
# Verify webhook receiver gets the POST within 3 seconds
```

---

## Phase 3: Pytest Test Suite

**File:** `lab/tests/test_security_controls.py`

```python
import pytest
import time
from security_middleware import (
    check_api_key_health,
    check_auth_anomaly,
    check_ip_rate_limit,
    reactivate_account,
)


class TestApiKeyHealth:
    def test_valid_key(self):
        keys = {"k1": {"created": time.time()}}
        ok, msg = check_api_key_health(keys, "k1")
        assert ok is True

    def test_expired_key(self):
        keys = {"k1": {"created": time.time() - 86400 * 100}}
        ok, msg = check_api_key_health(keys, "k1")
        assert ok is False
        assert "expired" in msg


class TestIpRateLimit:
    def test_under_limit(self):
        ok, msg = check_ip_rate_limit("1.2.3.4")
        assert ok is True
        ok, msg = check_ip_rate_limit("1.2.3.4")
        assert ok is True
        ok, msg = check_ip_rate_limit("1.2.3.4")
        assert ok is True

    def test_over_limit(self):
        ok, msg = check_ip_rate_limit("1.2.3.5")
        ok, msg = check_ip_rate_limit("1.2.3.5")
        ok, msg = check_ip_rate_limit("1.2.3.5")
        ok, msg = check_ip_rate_limit("1.2.3.5")
        assert ok is False
        assert "Rate limit" in msg


class TestAuthAnomaly:
    def test_ip_change_triggers_alert(self):
        log_calls = []
        def fake_log(event, **kwargs):
            log_calls.append((event, kwargs))

        alerts = check_auth_anomaly("u1", "1.1.1.1", "Mozilla/5.0", fake_log)
        assert alerts == []  # First seen

        alerts = check_auth_anomaly("u1", "2.2.2.2", "Mozilla/5.0", fake_log)
        assert "ip_change" in alerts
        assert log_calls[-1][0] == "auth_anomaly_ip"
```

**Run:**
```bash
cd lab && python -m pytest tests/ -v
```

---

## Phase 4: Re-Simulation & Validation

After all controls are integrated, re-run the three attack vectors.

### Validation Matrix

| Attack Vector | Before Tuning | After Tuning | Pass Criteria |
|---------------|---------------|--------------|---------------|
| Credential stuffing (5 attempts) | Account locked, no alert | IP rate limit + lockout + webhook alert | Alert received within 3s of 4th attempt |
| API key abuse (100-day key) | Full access, no detection | 401 expired + webhook alert | Key rejected, alert received |
| Dormant account reactivation | No alert | Alert with `was_dormant=true` + optional MFA gate | Alert received, reactivation tracked |
| IP change via API key | No detection | `auth_anomaly_ip` alert | Alert received on first IP change |

### Execution Steps

```bash
# 1. Start tuned lab
cd lab && docker compose up -d --build

# 2. Run red team scripts — expect failures (controls working)
cd attacker
python3 credential_stuffing.py http://localhost:5001 trader1    # Should hit rate limit
python3 api_key_abuse.py http://localhost:5001                   # Should get 401 on expired key
python3 dormant_account.py http://localhost:5001                 # Should trigger alert

# 3. Verify alerts
cat ../logs/auth.log | grep '"status": "alert"'
# Verify webhook receiver got POSTs
```

---

## Phase 5: Commit & Promote

1. Commit tuned code + tests to playbook repo
2. Update `03-debrief.md` with post-tuning metrics
3. Update `04-skill.md` validation checklist (all green)
4. Promote skill if all pass

---

## Timeline Estimate

| Phase | Task | Est. Time |
|-------|------|-----------|
| 1 | Write `security_middleware.py` | 30 min |
| 1 | Integrate into `app.py` | 20 min |
| 2 | Write `alert_pipeline.py` | 20 min |
| 3 | Write pytest tests | 30 min |
| 4 | Re-simulation + validation | 30 min |
| 5 | Documentation + commit | 20 min |
| **Total** | | **~3 hours** |

---

## Career Alignment

**Correction (2026-11-08):** A portfolio line here said "4 production-grade security controls" including "dormant account gating", with latency "<3 seconds". This is lab code, not production. The dormant-account control alerts; it does not gate. "<3 seconds" was a target. Measured results are in 06-post-tuning.md. The original text is in git history (commit a263419).
