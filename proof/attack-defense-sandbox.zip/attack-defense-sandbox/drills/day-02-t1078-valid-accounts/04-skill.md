# T1078 — Valid Accounts (Skill Promotion)

## Validation Checklist

- [x] Simulation executed successfully against sandbox target
- [x] Detection logic validated (confirmed absence of detection = validated gap)
- [ ] Remediation code tested and committed — PARTIAL (recommendations written, middleware drafted, not yet integrated)
- [x] Debrief metrics captured
- [x] Career alignment note written

**Status:** Ready for skill promotion with remediation integration pending.

---

## Skill Summary

This playbook documents a structured approach to simulating and detecting MITRE ATT&CK T1078 (Valid Accounts) in a finance-sector trading platform context. It covers three primary attack vectors:

1. **Credential Stuffing** — Username/password brute force against login endpoints
2. **API Key Abuse** — Leaked or stolen API keys used to bypass primary authentication
3. **Dormant Account Reactivation** — Stale service accounts re-enabled and abused for persistence

## Key Lessons

- Account lockout is effective against brute force but provides no proactive alerting
- API keys are a critical blind spot when they lack expiration, anomaly detection, and trade-size limits
- Dormant accounts are an attractive persistence vector when reactivation lacks approval workflows
- Auth logging without real-time alerting is telemetry waste

## Reusable Artifacts

| Artifact | Path | Purpose |
|----------|------|---------|
| Target app | `lab/mock-api/app.py` | FastAPI auth lab with lockout, API keys, dormancy |
| Attacker scripts | `lab/attacker/*.py` | Red team automation for all three vectors |
| Detection log | `lab/logs/auth.log` | Structured JSON auth telemetry |
| Debrief | `03-debrief.md` | Metrics, gaps, executive summary, remediation code |

## Promotion Note

Promoted to Hermes skill: `purple-team-ttp-t1078`
Date: Day 2
Next review: After remediation integration and re-simulation
