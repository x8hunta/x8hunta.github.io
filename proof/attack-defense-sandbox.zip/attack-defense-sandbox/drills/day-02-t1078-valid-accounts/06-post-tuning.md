# T1078 Post-Tuning Validation

> Controls implemented, tested, and re-simulated. Before vs After comparison.

---

## Controls Implemented

| Control | File | Function | Status |
|---------|------|----------|--------|
| API Key Age Enforcement | `lab/mock-api/security_middleware.py` | `check_api_key_health()` | ✅ Verified |
| IP Rate Limiting | `lab/mock-api/security_middleware.py` | `check_ip_rate_limit()` | ✅ Verified |
| Auth Anomaly Detection | `lab/mock-api/security_middleware.py` | `check_auth_anomaly()` | ✅ Verified |
| Dormant Account Gate | `lab/mock-api/security_middleware.py` | `reactivate_account()` | ✅ Verified |

**Integration:** All four controls wired into `lab/mock-api/app.py` with `=== BLUE TEAM ===` markers.

---

## Test Results

```
$ python -m pytest tests/test_security_controls.py -v
============================== 13 passed in 0.04s ===============================
```

| Test Suite | Tests | Passed |
|------------|-------|--------|
| API Key Health | 3 | 3 |
| IP Rate Limit | 3 | 3 |
| Auth Anomaly | 3 | 3 |
| Reactivate Account | 4 | 4 |

---

## Re-Simulation Matrix

### Before Tuning (Day 2 Initial Simulation)

| Attack Vector | Result | Detection |
|---------------|--------|-----------|
| Credential stuffing (5 attempts) | Account locked at 5th attempt | Lockout logged, no proactive alert |
| API key abuse (100-day key) | Full portfolio + trade + new key | None — undetected |
| Dormant account reactivation | Reactivated, full access | Logged, no real-time alert |

### After Tuning (Re-Simulation)

| Attack Vector | Result | Detection Latency |
|---------------|--------|-------------------|
| Credential stuffing (4th attempt) | **429 Rate limit exceeded** | `<1s` — `ip_rate_limit` alert |
| API key abuse (100-day key) | **401 API key expired** | `<1s` — `api_key_rejected` alert |
| Dormant account reactivation | Reactivated with `was_dormant: true` | `<1s` — `account_reactivated` alert |
| IP change via API key | Would trigger `auth_anomaly_ip` | N/A — validated via pytest |

---

## Log Evidence

### API Key Rejection
```json
{
  "timestamp": "2026-08-19T16:16:37.464498Z",
  "event": "api_key_rejected",
  "username": null,
  "ip": "172.31.101.1",
  "status": "alert",
  "details": {
    "reason": "API key expired (100 days old). Rotate your key.",
    "key_prefix": "cs_live_51HZk2x_"
  }
}
```

### IP Rate Limit
```json
{
  "timestamp": "2026-08-19T16:16:48.539856Z",
  "event": "ip_rate_limit",
  "username": "trader1",
  "ip": "172.31.101.1",
  "status": "alert",
  "details": {
    "reason": "Rate limit exceeded: 3 attempts in 60s"
  }
}
```

### Dormant Account Reactivation
```json
{
  "timestamp": "2026-08-19T16:18:05.469949Z",
  "event": "account_reactivated",
  "username": "service_api",
  "ip": "172.31.101.1",
  "status": "alert",
  "details": {
    "by_admin": "admin",
    "was_dormant": true,
    "days_inactive": 120.0
  }
}
```

---

## Detection Latency

| Control | Latency |
|---------|---------|
| API key expiration | `<1s` (rejected at auth middleware) |
| IP rate limiting | `<1s` (blocked before password check) |
| Dormant reactivation | `<1s` (alerted on admin action) |
| IP anomaly | N/A (pytest validated, requires multi-IP lab) |

**Before:** Infinite — no detection occurred  
**After:** `<1s` for all implemented controls

---

## Skill Promotion Checklist (Re-Evaluated)

- [x] Simulation executed successfully against sandbox target
- [x] Detection logic validated (fire rate, false positive test)
- [x] Remediation code tested and committed
- [x] Debrief metrics captured
- [x] Career alignment note written
- [x] **Post-tuning validation complete**

**Status:** All green. Playbook graduates to GitHub repo as completed artifact.

---

## Career Update

**Correction (2026-11-08):** The resume bullet here claimed "100% pytest coverage". Coverage was never measured. It also implied all three gaps were re-tested as attacks; IP anomaly detection was validated by unit test only. The original text is in git history (commit a263419).

Measured version:

> "Designed and ran MITRE ATT&CK T1078 (Valid Accounts) simulations against a mock trading app in an isolated lab. Found three detection gaps: expired API keys still accepted, dormant-account reactivation not alerted, no IP anomaly alerting. Added Python middleware controls; on re-simulation, credential stuffing, expired-key use and dormant-account reactivation each raised an alert in under 1 second. IP anomaly detection validated by unit test only."
