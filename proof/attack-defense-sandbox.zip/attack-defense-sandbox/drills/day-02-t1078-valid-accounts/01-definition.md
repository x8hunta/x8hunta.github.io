# T1078 — Valid Accounts

## Metadata
| Field | Value |
|-------|-------|
| MITRE ATT&CK ID | T1078 |
| Tactic | Initial Access / Persistence / Privilege Escalation / Defense Evasion |
| Sub-technique | T1078.001 (Local Accounts), T1078.004 (Cloud Accounts) |
| Sector Focus | Finance (Trading Platforms & Broker APIs) |
| Target Proxy | FastAPI trading backend with local auth + API key support |
| Simulation Date | Day 2 |

---

## 1. Threat Context

Valid account abuse is a top-tier threat in finance. Unlike malware or exploits, it uses legitimate credentials — making it inherently stealthy. Attackers obtain credentials via phishing, infostealers, credential stuffing, or dark web dumps. In trading environments, a single valid broker account can execute unauthorized trades, expose portfolio data, or pivot into back-office systems.

**Finance Sector Impact:**
- Unauthorized trade execution (market manipulation, front-running)
- Portfolio and PII exfiltration
- Regulatory breach (FINRA Rule 3110, SEC Regulation S-ID, PCI-DSS 8.2)
- Reputational damage and client attrition

---

## 2. Simulation Scope

### In-Scope
- Credential stuffing / password spray against login endpoint
- Abusing leaked/stolen valid API keys for trade endpoint access
- Re-enabling and abusing a dormant service account
- Detection of anomalous authentication patterns

### Out-of-Scope
- Live production Capital.com or any real broker API (read-only observation only)
- Actual financial transactions (synthetic data only)
- Malware deployment or credential harvesting (covered under T1539, Day 1)

---

## 3. Target Environment

```
Docker isolated network (purple-lab)
├── target-app — FastAPI trading backend (SQLite auth, API keys)
│   ├── POST /auth/login — username/password auth
│   ├── POST /auth/api-key — API key generation (authenticated)
│   ├── GET /portfolio — portfolio data (API key or JWT)
│   └── POST /trade — trade execution (API key or JWT, synthetic)
├── attacker — Kali/Debian container with Python + requests
└── siem-observer — Zeek or simple log aggregator for auth events
```

API endpoints / services / ports:
- target-app:8000 — FastAPI app
- attacker: any — attack scripts
- siem-observer: 5000 — log receiver (if deployed)

---

## 4. Expected Security Controls

| Control | Expected State | Detection Gap |
|---------|---------------|---------------|
| Account lockout after N failed attempts | Enabled (5 attempts) | Slow password sprays evade lockout; no alerting on lockout events |
| API key rotation policy | 90-day rotation | No detection of keys used beyond rotation window |
| Dormant account disablement | Accounts idle >90 days disabled | Re-enabling dormant accounts not logged or alerted |
| MFA on login | Enabled for web UI | API key endpoints may bypass MFA; key theft = full bypass |
| Geo/IP anomaly detection | Basic logging only | No automated alerting on impossible travel or new IPs |

---

## 5. Success Criteria

### Offensive (Red Team)
- [ ] Successfully authenticate via credential stuffing against /auth/login
- [ ] Access /portfolio using a stolen/leaked API key without username/password
- [ ] Re-enable dormant account and authenticate successfully
- [ ] Evade account lockout via slow spray or distributed attempts

### Defensive (Blue Team)
- [ ] Detect spike in failed auth attempts (credential stuffing)
- [ ] Detect API key usage from unexpected source IP or User-Agent
- [ ] Detect dormant account re-enablement event
- [ ] Measure detection latency from first malicious auth to alert generation

---

## 6. Career Alignment Note

This exercise maps to:
- **Threat Hunting:** Behavioral anomaly detection in authentication logs
- **Detection Engineering:** Writing rules for auth spike, impossible travel, dormant account events
- **Incident Response:** Valid account compromise investigation playbook
- **Application Security:** Secure auth design review (lockout, MFA, API key lifecycle)

**Correction (2026-11-08):** A resume bullet here claimed detection latency of "<5 minutes" via "Zeek + Python detection rules". It was written before the drill ran, so it was a target, not a result. The measured result is in 06-post-tuning.md (Python middleware, no Zeek). The original text is in git history (commit a263419).

---

## 7. Risk & Safety

- All execution inside isolated Docker network (purple-lab)
- No traffic leaves host
- Synthetic trade data only — no real positions or PII
- API rate limits will be enforced to avoid accidental DoS
- Destructive commands (account deletion, DB wipe) require explicit approval
