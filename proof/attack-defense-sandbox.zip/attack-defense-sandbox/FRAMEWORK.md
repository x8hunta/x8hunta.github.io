# Daily Purple Team Drill — Finance Sector

## Operating Rhythm

### Morning: TTP Selection & Threat Modeling (30–45 min)
1. Pull the next TTP from `TTP-BACKLOG.md`.
2. Define scope: target system, data classification, expected controls.
3. Map to MITRE ATT&CK: tactic, technique ID, sub-technique if applicable.
4. Identify detection gaps: what should fire, what might miss.
5. Output: `finance/<TTP>/01-definition.md`

### Mid-Day: Attack & Defense Loop (60–90 min)
1. Execute simulation in sandbox (Docker lab, WSL isolated net, or read-only probes).
2. Offense: run the attack sequence with precision.
3. Defense: review telemetry, SIEM queries, firewall logs, IDS alerts in real-time.
4. Iterate: pivot on detection, document blind spots.
5. Output: `finance/<TTP>/02-simulation.md` with full logs and packet captures.

### Afternoon: Debrief, Metrics & Documentation (30–45 min)
1. Quantify: dwell time, detection latency, MTTR, false positive rate.
2. Executive framing: risk exposure in USD, compliance gaps (PCI-DSS, SOC2, FINRA, Basel), remediation cost.
3. Tuning: updated detection rules, firewall policies, playbook adjustments.
4. Output: `finance/<TTP>/03-debrief.md`

### End of Day: Skill Promotion & Career Alignment (15–30 min)
1. Promote validated playbook to `~/.hermes/skills/` as reusable TTP skill.
2. Map exercise to current job pipeline: tie TTP practice directly to target role requirements.
3. Output: `finance/<TTP>/04-skill.md` + resume/interview story update.

---

## Post-Tuning: Recommended Implementation

After the initial simulation and debrief, every playbook includes a tuning phase that hardens the lab and proves the controls. This is not optional — it's how we close the loop between "we found a gap" and "we fixed the gap."

### Why this matters
A playbook that stops at `03-debrief.md` documents failure. A playbook that reaches `06-post-tuning.md` documents growth. The difference is what separates proof-of-work from proof-of-learning.

### Structure

```
finance/<TTP>/
├── 01-definition.md       # Phase 2 — Scope
├── 02-simulation.md        # Phase 3 — Attack & raw telemetry
├── 03-debrief.md           # Phase 4 — Metrics, gaps, executive summary
├── 04-skill.md             # Phase 5 — Skill promotion validation
├── 05-blue-team-tuning-plan.md  # OPTIONAL — Detailed implementation roadmap
└── 06-post-tuning.md       # Phase 6 — Validated controls, re-sim results
```

### What goes in `06-post-tuning.md`

1. **Controls Implemented** — List each control with file path and code snippet
2. **Test Results** — Pytest output or manual validation logs
3. **Re-Simulation Matrix** — Before vs After comparison table
4. **Detection Latency** — Time from attack action to alert generation
5. **Screenshots / Logs** — Evidence that controls fired
6. **Career Update** — Resume bullet updated only with improvements measured in the drill. Targets are labelled as targets. (Wording corrected 2026-11-08.)

### Visual: Before vs After

Every `06-post-tuning.md` should include a comparison table:

| Attack Vector | Pre-Tuning | Post-Tuning | Detection Latency |
|---------------|------------|-------------|-------------------|
| Vector 1 | Undetected | Blocked + Alerted | <3 seconds |
| Vector 2 | ... | ... | ... |

### Skill Promotion Update

After tuning, the skill promotion checklist is re-evaluated:

- [x] Simulation executed successfully against sandbox target
- [x] Detection logic validated (fire rate, false positive test)
- [x] Remediation code **tested and committed**
- [x] Debrief metrics captured
- [x] Career alignment note written
- [x] **Post-tuning validation complete** (NEW)

Only when all boxes are green does the playbook graduate to the GitHub repo as a completed artifact.

---

## File Naming Convention

```
~/shadowops/purple-playbooks/
├── FRAMEWORK.md
├── TTP-BACKLOG.md
└── finance/
    ├── T1539-Steal-Web-Session-Cookie/
    │   ├── 01-definition.md
    │   ├── 02-simulation.md
    │   ├── 03-debrief.md
    │   └── 04-skill.md
    └── T1078-Valid-Accounts/
        └── ...
```

## Skill Promotion Criteria

A playbook graduates to `~/.hermes/skills/` only when:
- [ ] Simulation executed successfully against sandbox target
- [ ] Detection logic validated (fire rate, false positive test)
- [ ] Remediation code tested and committed
- [ ] Debrief metrics captured
- [ ] Career alignment note written

## Sandbox Boundaries

- No live production systems without explicit approval
- No real customer data
- Financial API probes: read-only unless scoped otherwise
- Network simulations: Docker/WSL isolated subnets only
