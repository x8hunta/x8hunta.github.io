# Proof bundle: Attack and Defense Sandbox

Label: TRAINING LAB. Mock trading app with made-up accounts, in an isolated Docker lab. My own scripts were the attacker.
Source: private repo, commit 4038e4cd95aa72e484dffc34404904c3a8993ad2 (tag proof-rel-001). Built 2026-11-08.

All keys, passwords and secrets in this bundle are fake lab values (for example `cs_live_51HZk2x_sample_leaked_key_t1078`).
The attack scripts target only the lab container `mock-trading-api`. They use standard techniques (password guessing, reuse of an expired API key, reviving a dormant account).

## Which file backs each claim
| Claim | File |
|---|---|
| Before: attacks went unalerted | drills/day-02-t1078-valid-accounts/02-simulation.md, 03-debrief.md |
| After: three attacks each alerted in under 1 second | drills/day-02-t1078-valid-accounts/06-post-tuning.md |
| Reviving a dead account alerts, it doesn't block | 06-post-tuning.md ("Reactivated with was_dormant: true") |
| IP anomaly check tested in code only | evidence/pytest-day02.txt (re-run 2026-11-08 on this commit) |
| Cookie theft went undetected; sensor blind to container traffic | drills/day-01-t1539-cookie-theft/02-simulation.md, 03-debrief.md |

## Corrections
Seven lines that claimed unmeasured results were corrected on 2026-11-08 with dated notes in the files (search "Correction (2026-11-08)").

## What this doesn't prove
- Lab only, fake data. An alert is not a block.
- The middleware has an optional MFA check before a dormant account can be revived, and a unit test shows it works (`test_reactivate_requires_mfa_when_dormant`). The lab app calls it with that check switched off (`require_mfa=False` in mock-api/app.py), so in the re-run attack, reviving the account raised an alert but was not blocked.
- The cookie-theft exercise found its gaps but was not re-tested after fixes.

## Check this bundle
`sha256sum -c FILES.sha256` inside this folder.
