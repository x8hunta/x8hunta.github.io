# Proof bundle: A network fixer that has to ask permission first

Label: SIMULATED. Training demonstrator on a simulated network. Not client work. No real devices.
Source: private repo, commit b9b0f1c66173873b17bea266b110fa383486e15e (tag proof-rel-001). Built 2026-11-08.

## Which file backs each claim
| Claim | File |
|---|---|
| An unapproved fix is refused (409) | evidence/http-gate-test.txt, line "apply BEFORE approval" |
| An approved fix clears the problem | evidence/selftest.txt ("G4 approved + applied"), http-gate-test.txt ("apply") |
| A decided fix can't be approved or rejected again | evidence/http-gate-test.txt ("approve again", "reject after applied") |
| The history log can't be edited or deleted | evidence/selftest.txt ("P1 'UPDATE' refused", "P1 'DELETE' refused"); code/db.py triggers |
| Reset keeps the history | evidence/http-gate-test.txt, audit trail after the final reset |

## What this doesn't prove
- Simulated network only. The "fixer" follows fixed rules; there is no AI in it.
- The approver is a fixed name ("operator"), not a real login. The API has no authentication; it runs on localhost only.
- Append-only is enforced inside the database. Someone with file access could still replace the whole database file.

## Not included
3d-force-graph v1.80.2 (third-party, not included). Expected static/vendor/3d-force-graph.min.js sha256 ae9b5ca9d525095978d0f5d23f9136dfe177b2e949773102ffbf145dd7776f04.

## Check this bundle
`sha256sum -c FILES.sha256` inside this folder. The zip itself is listed in SHA256SUMS on the Proof page.
