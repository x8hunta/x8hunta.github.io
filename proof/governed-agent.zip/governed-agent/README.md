# Proof bundle: A network fixer that has to ask permission first

Label: SIMULATED. Training demonstrator on a simulated network. Not client work. No real devices.
Source: private repo, commit 08009ce36018a32482e70d987a6a59147cfc58f2 (tag proof-rel-002). Built 2026-11-09. Release REL-002, replacing REL-001.

## Which file backs each claim
| Claim | File |
|---|---|
| An unapproved fix is refused (409) | evidence/http-gate-test.txt, line "apply BEFORE approval" |
| An approved fix clears the problem | evidence/selftest.txt ("G4 approved + applied"), http-gate-test.txt ("apply") |
| A decided fix can't be approved or rejected again | evidence/http-gate-test.txt ("approve again", "reject after applied") |
| The app can't edit or delete the history log | evidence/selftest.txt ("P1 'UPDATE' refused", "P1 'DELETE' refused"); code/db.py triggers |
| Reset keeps the history | evidence/http-gate-test.txt, audit trail after the final reset |
| The 3D map turns the faulty host from red to green after an approved fix | evidence/3d-map-before.png, 3d-map-after.png, 3d-map-capture.txt |

## Run the checks yourself
In `code/`, with Python 3 and `pip install -r requirements.txt`:
- `python3 agent.py` runs the self-test. It creates `governed_agent.db` in that folder.
- `python3 http_gate_test.py` starts the app on 127.0.0.1:8601 against a temporary database, runs the
  sequence over the real API and checks every step. Exit code 0 means all checks passed.
The 3D map needs the third-party library listed under "Not included".

## What this doesn't prove
- Simulated network only. The "fixer" follows fixed rules; there is no AI in it.
- The approver is a fixed name ("operator"), not a real login. The API has no authentication; it runs on localhost only.
- Append-only is enforced inside the database. Someone with file access could still delete or replace the whole database file. There is no copy kept anywhere else yet.
- The 3D stills show no node names; the red node is identified by the app's state (see 3d-map-capture.txt).

## Changes since REL-001
- Added code/http_gate_test.py, so the HTTP gate test can be re-run, not only read.
- Added the 3D map captures.
- Reworded the log claim: "can't be edited or deleted" became "the app can't edit or delete", because deleting the database file would remove the log.
- REL-001 governed-agent.zip sha256 597d92db33d8f7b21515520b3e30f0a546988c2b24ae5360809d931b43af462d, replaced 2026-11-09.

## Not included
3d-force-graph v1.80.2 (third-party, not included). Expected static/vendor/3d-force-graph.min.js sha256 ae9b5ca9d525095978d0f5d23f9136dfe177b2e949773102ffbf145dd7776f04.

## Check this bundle
`sha256sum -c FILES.sha256` inside this folder. The zip itself is listed in SHA256SUMS on the Proof page.
