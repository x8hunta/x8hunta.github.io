"""HTTP gate test: checks the approval gate through the real API, on a throwaway database.

Run from this folder, with the packages in requirements.txt installed:
    python3 http_gate_test.py
It starts the app on 127.0.0.1:8601 against a temporary database, sends the demo
sequence, prints each response and the audit trail, then checks every step.
Your real database is not touched. Exit code 0 means every check passed.
"""
import json
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

PORT = 8601
BASE = f"http://127.0.0.1:{PORT}/api/"
# (label, path, expected HTTP status)
STEPS = [
    ("reset", "reset", 200),
    ("simulate Host_B blank", "simulate/blank/Host_B", 200),
    ("reconcile", "reconcile", 200),
    ("agent proposes", "propose", 200),
    ("apply BEFORE approval", "apply/1", 409),
    ("approve", "approve/1", 200),
    ("apply", "apply/1", 200),
    ("approve again", "approve/1", 409),
    ("reject after applied", "reject/1", 409),
    ("reset", "reset", 200),
]
# Audit events that must survive the final reset, in order.
EXPECTED_EVENTS = ["reset", "detected", "proposed", "apply_blocked", "approved", "applied",
                   "verified", "decision_blocked", "decision_blocked", "reset"]


def post(path):
    try:
        r = urllib.request.urlopen(urllib.request.Request(BASE + path, method="POST"))
        return r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


def main():
    here = Path(__file__).resolve().parent
    tmp = Path(tempfile.mkdtemp())
    db_file = tmp / "gate-test.db"
    server = (f"import db, uvicorn; from pathlib import Path; db.DB_PATH = Path({str(db_file)!r}); "
              f"import app; uvicorn.run(app.app, host='127.0.0.1', port={PORT}, log_level='warning')")
    srv = subprocess.Popen([sys.executable, "-c", server], cwd=here,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    failures = []
    try:
        for _ in range(40):
            try:
                urllib.request.urlopen(f"http://127.0.0.1:{PORT}/", timeout=1)
                break
            except OSError:
                time.sleep(0.25)
        print("HTTP gate test (localhost, throwaway database)")
        for label, path, want in STEPS:
            code, body = post(path)
            print(f"{label:24} [{code}] {body[:160]}")
            if code != want:
                failures.append(f"{label}: got {code}, expected {want}")
        rows = sqlite3.connect(db_file).execute("select id, actor, event, host, detail from audit").fetchall()
        print("\nAudit trail after the final reset (nothing deleted):")
        for row in rows:
            print(row)
        events = [r[2] for r in rows]
        if events != EXPECTED_EVENTS:
            failures.append(f"audit events {events}, expected {EXPECTED_EVENTS}")
    finally:
        srv.terminate()
        srv.wait()
        shutil.rmtree(tmp)

    if failures:
        print("\nVERIFY FAILED:\n  " + "\n  ".join(failures))
        sys.exit(1)
    print("\nVERIFY OK: unapproved apply refused (409); approved fix applied; repeat decisions refused (409);"
          "\n           audit trail complete and kept through reset.")


if __name__ == "__main__":
    main()
