"""Governed Agent — divergence detector (G2).

Reconciles live state against the register (AAR-1). Every disagreement is a
logged finding: reality is what's observed, the register is the intent.

    python3 detector.py        # demo: clean state (0 findings), then Host_B blank (1)
"""
import db


def reconcile(conn):
    """Recompute open findings from live vs register. Returns the open findings."""
    db.clear_open_findings(conn)
    register = db.get_register(conn)
    live = db.get_live(conn)

    for host, r in register.items():
        lv = live.get(host)
        if lv is None:
            db.add_finding(conn, host, "not_observed",
                           "in register but not seen on the network",
                           expected=f"{r['ip']}/{r['mask']} gw {r['gateway']}",
                           observed="absent")
            continue
        if not lv["ip"] or not lv["mask"] or not lv["gateway"]:
            missing = ", ".join(f for f in ("ip", "mask", "gateway") if not lv[f])
            db.add_finding(conn, host, "missing_l3",
                           f"no {missing} — host has no L3 identity",
                           expected=f"{r['ip']}/{r['mask']} gw {r['gateway']}",
                           observed="blank")
            continue
        for field in ("ip", "mask", "gateway"):
            if lv[field] != r[field]:
                db.add_finding(conn, host, "divergence",
                               f"{field} does not match the register",
                               expected=r[field], observed=lv[field])

    for host in live:
        if host not in register:
            db.add_finding(conn, host, "unregistered",
                           "observed on the network but not in the register",
                           expected="—", observed=live[host]["ip"] or "blank")

    return db.list_findings(conn, "open")


def _print(findings):
    if not findings:
        print("  no findings — live state matches the register.\n")
        return
    for f in findings:
        print(f"  [{f['kind']:12}] {f['host']:8} {f['detail']}")
        print(f"               expected: {f['expected']}   observed: {f['observed']}")
    print()


if __name__ == "__main__":
    conn = db.connect()
    db.init_db(conn)
    db.seed_register(conn)

    print("1) Live state matches the register:")
    db.seed_live_match(conn)
    _print(reconcile(conn))

    print("2) Host_B observed with no L3 config (the Witty 1.5 fault):")
    db.blank_live_l3(conn, "Host_B")
    found = reconcile(conn)
    _print(found)

    assert len(found) == 1 and found[0]["host"] == "Host_B" and found[0]["kind"] == "missing_l3", \
        "expected exactly one missing_l3 finding on Host_B"
    print("VERIFY OK: clean state = 0 findings; Host_B blank = 1 missing_l3 finding.")
    conn.close()
