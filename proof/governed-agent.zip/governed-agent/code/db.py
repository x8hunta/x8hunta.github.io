"""Governed Agent — data layer: IPAM register, live state, findings.

TRAINING / DEMONSTRATOR. Simulated network. Not client work.

- register: every host's INTENDED L3 config — the source of truth (AAR-1 req 1).
- live:     the SIMULATED observed state; may diverge (blank or wrong values).
- findings: divergences the detector logs (G2).

Run directly to (re)create and seed the register, then print it:
    python3 db.py
"""
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "governed_agent.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS register (
    host     TEXT PRIMARY KEY,
    ip       TEXT NOT NULL,
    mask     TEXT NOT NULL,
    gateway  TEXT NOT NULL,
    subnet   TEXT NOT NULL,   -- CIDR, e.g. 192.168.1.0/29
    switch   TEXT NOT NULL,
    note     TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS live (
    host        TEXT PRIMARY KEY,
    ip          TEXT,          -- nullable: blank models no L3 identity
    mask        TEXT,
    gateway     TEXT,
    observed_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS findings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    host        TEXT NOT NULL,
    kind        TEXT NOT NULL,   -- missing_l3 | divergence | not_observed | unregistered
    detail      TEXT NOT NULL,
    expected    TEXT,
    observed    TEXT,
    status      TEXT DEFAULT 'open',
    detected_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS proposals (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    host        TEXT NOT NULL,
    kind        TEXT NOT NULL,   -- finding kind it remediates
    action      TEXT NOT NULL,   -- human-readable remediation
    set_ip      TEXT,
    set_mask    TEXT,
    set_gateway TEXT,
    status      TEXT DEFAULT 'pending',   -- pending | approved | rejected | applied
    created_by  TEXT DEFAULT 'agent',
    created_at  TEXT DEFAULT CURRENT_TIMESTAMP,
    decided_by  TEXT,
    decided_at  TEXT
);
CREATE TABLE IF NOT EXISTS audit (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    ts     TEXT DEFAULT CURRENT_TIMESTAMP,
    actor  TEXT NOT NULL,
    event  TEXT NOT NULL,   -- detected|proposed|approved|rejected|apply_blocked|applied|verified
    host   TEXT,
    detail TEXT DEFAULT ''
);
-- Append-only: the database itself refuses edits and deletes on the audit trail.
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit
BEGIN SELECT RAISE(ABORT, 'audit is append-only'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit
BEGIN SELECT RAISE(ABORT, 'audit is append-only'); END;
"""

# Intended config — the source of truth. (Witty 1.5 scheme.)
SEED = [
    ("Host_A", "192.168.1.2", "255.255.255.248", "192.168.1.1", "192.168.1.0/29", "SW1", "bottom subnet"),
    ("Host_B", "192.168.1.3", "255.255.255.248", "192.168.1.1", "192.168.1.0/29", "SW1", "bottom subnet"),
    ("Host_C", "192.168.2.2", "255.255.255.248", "192.168.2.1", "192.168.2.0/29", "SW2", "top subnet"),
    ("Host_D", "192.168.2.3", "255.255.255.248", "192.168.2.1", "192.168.2.0/29", "SW2", "top subnet"),
]


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(conn):
    conn.executescript(SCHEMA)
    conn.commit()


def seed_register(conn):
    conn.executemany(
        "INSERT OR REPLACE INTO register "
        "(host, ip, mask, gateway, subnet, switch, note) VALUES (?,?,?,?,?,?,?)",
        SEED,
    )
    conn.commit()


def get_register(conn):
    """{host: {ip, mask, gateway, subnet, switch}}"""
    rows = conn.execute("SELECT * FROM register").fetchall()
    return {r["host"]: dict(r) for r in rows}


def set_live(conn, host, ip, mask, gateway):
    conn.execute(
        "INSERT INTO live (host, ip, mask, gateway) VALUES (?,?,?,?) "
        "ON CONFLICT(host) DO UPDATE SET ip=excluded.ip, mask=excluded.mask, "
        "gateway=excluded.gateway, observed_at=CURRENT_TIMESTAMP",
        (host, ip, mask, gateway),
    )
    conn.commit()


def seed_live_match(conn):
    """Observed state matches the register exactly (no divergence)."""
    for host, r in get_register(conn).items():
        set_live(conn, host, r["ip"], r["mask"], r["gateway"])


def blank_live_l3(conn, host):
    """Model a host on the network with no L3 identity (the Witty 1.5 fault)."""
    set_live(conn, host, None, None, None)


def get_live(conn):
    """{host: {ip, mask, gateway}}"""
    rows = conn.execute("SELECT host, ip, mask, gateway FROM live").fetchall()
    return {r["host"]: dict(r) for r in rows}


def add_finding(conn, host, kind, detail, expected, observed):
    conn.execute(
        "INSERT INTO findings (host, kind, detail, expected, observed) VALUES (?,?,?,?,?)",
        (host, kind, detail, expected, observed),
    )
    conn.commit()


def clear_open_findings(conn):
    conn.execute("DELETE FROM findings WHERE status='open'")
    conn.commit()


def list_findings(conn, status="open"):
    return conn.execute(
        "SELECT * FROM findings WHERE status=? ORDER BY host, id", (status,)
    ).fetchall()


def add_proposal(conn, host, kind, action, set_ip, set_mask, set_gateway, created_by="agent"):
    cur = conn.execute(
        "INSERT INTO proposals (host, kind, action, set_ip, set_mask, set_gateway, created_by) "
        "VALUES (?,?,?,?,?,?,?)",
        (host, kind, action, set_ip, set_mask, set_gateway, created_by),
    )
    conn.commit()
    return cur.lastrowid


def get_proposal(conn, pid):
    return conn.execute("SELECT * FROM proposals WHERE id=?", (pid,)).fetchone()


def set_proposal_status(conn, pid, status, decided_by=None):
    conn.execute(
        "UPDATE proposals SET status=?, decided_by=?, decided_at=CURRENT_TIMESTAMP WHERE id=?",
        (status, decided_by, pid),
    )
    conn.commit()


def list_proposals(conn, status=None):
    if status:
        return conn.execute(
            "SELECT * FROM proposals WHERE status=? ORDER BY id", (status,)
        ).fetchall()
    return conn.execute("SELECT * FROM proposals ORDER BY id").fetchall()


def add_audit(conn, actor, event, host=None, detail=""):
    conn.execute(
        "INSERT INTO audit (actor, event, host, detail) VALUES (?,?,?,?)",
        (actor, event, host, detail),
    )
    conn.commit()


def list_audit(conn):
    return conn.execute("SELECT * FROM audit ORDER BY id").fetchall()


if __name__ == "__main__":
    conn = connect()
    init_db(conn)
    seed_register(conn)
    reg = get_register(conn)
    print(f"IPAM register @ {DB_PATH.name} — {len(reg)} hosts (source of truth, AAR-1)\n")
    print(f"{'HOST':8} {'IP':14} {'MASK':17} {'GATEWAY':14} {'SUBNET':17} {'SW'}")
    print("-" * 78)
    for host, r in sorted(reg.items()):
        print(f"{host:8} {r['ip']:14} {r['mask']:17} {r['gateway']:14} {r['subnet']:17} {r['switch']}")
    conn.close()
