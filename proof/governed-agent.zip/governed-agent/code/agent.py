"""Governed Agent — propose, the Human-Digital Handshake gate, apply (G3, G4).

The agent DETECTS and PROPOSES. An accountable human APPROVES. Only then does a
change APPLY, after which the agent RECONCILES and records the whole chain in an
append-only audit trail.

Gate rule: apply_proposal refuses anything not in state 'approved'.

    python3 agent.py   # demo: propose, block unapproved apply, reject, approve+apply+verify
"""
import db
from detector import reconcile


class GateError(Exception):
    """Raised when apply is attempted on a proposal that is not approved."""


def propose_for_open_findings(conn, actor="agent"):
    """Turn each remediable open finding into a pending proposal (register values)."""
    register = db.get_register(conn)
    made = []
    for f in db.list_findings(conn, "open"):
        if f["kind"] not in ("missing_l3", "divergence", "not_observed"):
            continue  # unregistered hosts are a human call, not an auto-fix
        r = register.get(f["host"])
        if not r:
            continue
        action = f"set {f['host']} to {r['ip']} / {r['mask']} gw {r['gateway']}"
        db.add_audit(conn, actor, "detected", f["host"], f["detail"])
        pid = db.add_proposal(conn, f["host"], f["kind"], action,
                              r["ip"], r["mask"], r["gateway"], created_by=actor)
        db.add_audit(conn, actor, "proposed", f["host"], action)
        made.append(pid)
    return made


def _require_pending(conn, pid, actor, verb):
    """A decision is only valid on a pending proposal; anything else is refused and logged."""
    p = db.get_proposal(conn, pid)
    if p is None:
        raise GateError(f"no proposal {pid}")
    if p["status"] != "pending":
        db.add_audit(conn, actor, "decision_blocked", p["host"],
                     f"{verb} proposal {pid} refused: it is '{p['status']}', not pending")
        raise GateError(f"proposal {pid} is '{p['status']}', not pending")


def approve(conn, pid, actor):
    _require_pending(conn, pid, actor, "approve")
    db.set_proposal_status(conn, pid, "approved", decided_by=actor)
    db.add_audit(conn, actor, "approved", _host(conn, pid), f"proposal {pid}")


def reject(conn, pid, actor):
    _require_pending(conn, pid, actor, "reject")
    db.set_proposal_status(conn, pid, "rejected", decided_by=actor)
    db.add_audit(conn, actor, "rejected", _host(conn, pid), f"proposal {pid}")


def apply_proposal(conn, pid, actor):
    """THE GATE. Apply only if approved; then reconcile and log the trail."""
    p = db.get_proposal(conn, pid)
    if p is None:
        raise GateError(f"no proposal {pid}")
    if p["status"] != "approved":
        db.add_audit(conn, actor, "apply_blocked", p["host"],
                     f"proposal {pid} is '{p['status']}', not approved")
        raise GateError(f"proposal {pid} is '{p['status']}', not approved")

    db.set_live(conn, p["host"], p["set_ip"], p["set_mask"], p["set_gateway"])
    db.set_proposal_status(conn, pid, "applied", decided_by=p["decided_by"])
    db.add_audit(conn, actor, "applied", p["host"], p["action"])

    remaining = [f for f in reconcile(conn) if f["host"] == p["host"]]
    if remaining:
        db.add_audit(conn, actor, "verified", p["host"], "FAILED: finding still open")
    else:
        db.add_audit(conn, actor, "verified", p["host"], "OK: reconciled, no open finding")
    return not remaining


def _host(conn, pid):
    p = db.get_proposal(conn, pid)
    return p["host"] if p else None


# --- demo / verification -----------------------------------------------------
def _setup(conn):
    db.init_db(conn)
    db.seed_register(conn)
    db.seed_live_match(conn)
    db.blank_live_l3(conn, "Host_B")   # the Witty 1.5 fault
    reconcile(conn)


if __name__ == "__main__":
    conn = db.connect()
    _setup(conn)
    assert len(db.list_findings(conn, "open")) == 1, "expected the Host_B finding"

    # G3: propose
    pids = propose_for_open_findings(conn)
    assert len(pids) == 1 and db.get_proposal(conn, pids[0])["status"] == "pending"
    print(f"G3  proposed: {db.get_proposal(conn, pids[0])['action']}  [pending]")

    # G3: the gate blocks an unapproved apply
    try:
        apply_proposal(conn, pids[0], "operator")
        raise SystemExit("GATE FAILED: unapproved apply went through")
    except GateError as e:
        print(f"G3  gate held: {e}")
    assert db.get_live(conn)["Host_B"]["ip"] is None, "Host_B must still be blank"

    # G3: reject path
    reject(conn, pids[0], "operator")
    assert db.get_proposal(conn, pids[0])["status"] == "rejected"
    assert db.get_live(conn)["Host_B"]["ip"] is None, "reject must not change live"
    print("G3  reject works: proposal rejected, live unchanged")

    # G4: a fresh proposal, approved, then applied + verified
    reconcile(conn)  # finding still open
    pid = propose_for_open_findings(conn)[0]
    approve(conn, pid, "operator")
    assert db.get_proposal(conn, pid)["status"] == "approved"
    ok = apply_proposal(conn, pid, "operator")
    print(f"G4  approved + applied: Host_B -> {db.get_live(conn)['Host_B']['ip']}")

    assert ok, "apply should have reconciled the finding away"
    assert len(db.list_findings(conn, "open")) == 0, "no open findings after fix"
    assert db.get_proposal(conn, pid)["status"] == "applied"

    events = [a["event"] for a in db.list_audit(conn) if a["host"] == "Host_B"]
    for stage in ("detected", "proposed", "apply_blocked", "rejected", "approved", "applied", "verified"):
        assert stage in events, f"audit missing '{stage}'"
    print("G4  audit trail:", " -> ".join(events))

    # P1: decisions only on pending proposals
    for verb, fn in (("approve", approve), ("reject", reject)):
        try:
            fn(conn, pid, "operator")   # pid is 'applied' now
            raise SystemExit(f"GATE FAILED: {verb} accepted on an applied proposal")
        except GateError as e:
            print(f"P1  {verb} refused: {e}")
    assert db.get_proposal(conn, pid)["status"] == "applied"

    # P1: the audit trail is append-only at the database level
    import sqlite3
    for sql in ("UPDATE audit SET detail='tampered'", "DELETE FROM audit"):
        try:
            conn.execute(sql)
            raise SystemExit(f"AUDIT NOT APPEND-ONLY: '{sql}' went through")
        except sqlite3.IntegrityError as e:
            print(f"P1  '{sql.split()[0]}' refused: {e}")
    assert not any(a["detail"] == "tampered" for a in db.list_audit(conn))
    print("\nVERIFY OK: gate blocks unapproved apply; reject works; approve applies,")
    print("           reconciles the finding away, and logs the full chain.")
    conn.close()
