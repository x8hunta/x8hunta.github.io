# Governed Agent (GA) demonstrator

**TRAINING / DEMONSTRATOR. Simulated network. Not client work. No real devices.**

Governance for agentic network operations. An agent **detects** config divergence,
**proposes** a fix, holds it at the **Human-Digital Handshake gate**, applies only on
human **approval**, **reconciles** against the IPAM register (AAR-1), and records the
whole chain in an **append-only audit trail**.

The point is the control layer, not the automation: the agent recommends, the
accountable human decides, and nothing touches state unapproved. That is the half
of "agentic NetOps" most demos skip.

Built on the Witty lab track — Host_B's missing L3 config (lab 1.5) is the canonical
test fixture, and the controls (AAR-1, the Human-Digital Handshake) are the ones
earned there. See `GOVERNANCE.md` for the control-to-code mapping.

## Run

```bash
cd ~/shadowops/governed-agent
python3 -m venv venv && venv/bin/pip install -r requirements.txt   # first time
venv/bin/uvicorn app:app --host 127.0.0.1 --port 8600
```

Open `http://127.0.0.1:8600` (console) in Firefox. The 3D topology is linked there,
or at `http://127.0.0.1:8600/static/topology.html`.

Demo flow: **Reset** → **Simulate: Host_B blank** → **Reconcile** (a finding appears)
→ **Agent: propose fixes** → **Approve** → **Apply** (finding clears, Host_B goes green).
Try **Apply** before approving — the gate refuses it.

## Components

| File | Role |
|---|---|
| `db.py` | SQLite data layer: register (source of truth), live state, findings, proposals, audit |
| `detector.py` | Reconciles live vs register; logs findings (G2) |
| `agent.py` | Propose, approve/reject, the apply gate, reconcile + audit (G3, G4) |
| `app.py` | FastAPI dashboard API (G5) |
| `static/index.html` | Operator console: findings, the approval gate, audit trail |
| `static/topology.html` | 3D topology: exploded-view assemble on load, findings glow red/green (G6) |
| `static/vendor/` | 3d-force-graph v1.80.2 (MIT), vendored locally |

## Self-tests

```bash
python3 detector.py   # clean = 0 findings; Host_B blank = 1 finding
python3 agent.py      # gate blocks unapproved apply; reject works; approve applies + verifies
```

## Status
G1–G7 complete and verified (2026-11-06). See `~/shadowops/PHASES.md`.

## Notes
- `governed_agent.db` and `venv/` are generated — see `.gitignore`.
- No real devices, no client data. Every surface is labelled a training demonstrator.
