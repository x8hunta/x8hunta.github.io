# Governance mapping

How the controls earned in the Witty lab track are enforced in this code. This is
the document an auditor reads: each control names the artifact that proves it works.

## AAR-1 — Address Authority & Reconciliation

| # | Requirement | Where it lives |
|---|---|---|
| 1 | Intended address/mask/gateway live in an IPAM register — the source of truth, not the diagram or the device | `db.py` `register` table, seeded from the Witty 1.5 scheme |
| 2 | A host is not in service until live config matches its register entry | `detector.reconcile` flags any live ≠ register as a finding |
| 3 | A scheduled scan reconciles live against the register; divergence is a logged finding | `detector.reconcile`; `POST /api/reconcile`; `findings` table |
| 4 | On divergence, reality is the finding; corrected under change control | a fix lands **only** through an approved proposal (`agent.apply_proposal`) |
| 5 | Every gateway must name the real router; rogue-gateway insertion caught | gateway compared field-by-field in `reconcile` (`divergence` finding) |

## Human-Digital Handshake

| Step | Where it lives |
|---|---|
| Automation **detects and proposes** | `agent.propose_for_open_findings` (actor `agent`) |
| An accountable **human resolves** | `approve` / `reject` (actor `operator`) |
| **The gate** — nothing applies unapproved | `agent.apply_proposal` raises `GateError` unless status is `approved`; API returns HTTP 409 |
| **Every override logged** | `audit` table: `detected → proposed → approved/rejected → apply_blocked → applied → verified` |

## Doctrine in the design

- **If it isn't documented, it didn't happen** — the `audit` table is append-only, enforced by database triggers that refuse UPDATE and DELETE (`db.py`); Reset keeps the trail and logs itself. Every decision and action is a row with actor and timestamp. Decisions are accepted only on pending proposals; anything else is refused and logged as `decision_blocked`.
- **Reality wins; the record is the finding** — `reconcile` writes findings from observed state, never trusting the register over the device.
- **A control solves the class, not the incident** — one loop handles `missing_l3`, `divergence`, `not_observed`, and `unregistered`, not just Host_B.
- **Separate detection from resolution** — the agent cannot approve its own proposal; approval is a different actor.

## Lineage

The canonical fixture is Witty lab 1.5: Host_B reached the network with no L3
identity and no register to catch it (`~/shadowops/lab/2026-11-06-witty-1.5.md`,
write-up NAL-003). This demonstrator turns that manual catch into a governed,
audited control loop.
