"""Governed Agent — dashboard API (G5).

FastAPI + vanilla JS + SQLite. Serves the console where a human sees findings,
approves or rejects the agent's proposals, and reads the audit trail.

    venv/bin/uvicorn app:app --host 127.0.0.1 --port 8600

TRAINING / DEMONSTRATOR. Simulated network. Not client work.
"""
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

import db
import agent
from detector import reconcile

HERE = Path(__file__).parent
OPERATOR = "operator"   # the accountable human at the console
app = FastAPI(title="Governed Agent")
app.mount("/static", StaticFiles(directory=str(HERE / "static")), name="static")


@app.on_event("startup")
def _startup():
    conn = db.connect()
    db.init_db(conn)
    db.seed_register(conn)
    if not db.get_live(conn):
        db.seed_live_match(conn)
    conn.close()


def _rows(rows):
    return [dict(r) for r in rows]


@app.get("/", response_class=HTMLResponse)
def index():
    return (HERE / "static" / "index.html").read_text()


@app.get("/api/state")
def state():
    conn = db.connect()
    out = {
        "register": _rows(conn.execute("SELECT * FROM register ORDER BY host").fetchall()),
        "live": _rows(conn.execute("SELECT * FROM live ORDER BY host").fetchall()),
        "findings": _rows(db.list_findings(conn, "open")),
        "proposals": _rows(db.list_proposals(conn)),
        "audit": _rows(db.list_audit(conn)),
    }
    conn.close()
    return out


@app.post("/api/reconcile")
def api_reconcile():
    conn = db.connect()
    found = _rows(reconcile(conn))
    conn.close()
    return {"findings": found}


@app.post("/api/propose")
def api_propose():
    conn = db.connect()
    pids = agent.propose_for_open_findings(conn)
    conn.close()
    return {"proposed": pids}


@app.post("/api/approve/{pid}")
def api_approve(pid: int):
    conn = db.connect()
    try:
        agent.approve(conn, pid, OPERATOR)
        return {"ok": True}
    except agent.GateError as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=409)
    finally:
        conn.close()


@app.post("/api/reject/{pid}")
def api_reject(pid: int):
    conn = db.connect()
    try:
        agent.reject(conn, pid, OPERATOR)
        return {"ok": True}
    except agent.GateError as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=409)
    finally:
        conn.close()


@app.post("/api/apply/{pid}")
def api_apply(pid: int):
    conn = db.connect()
    try:
        ok = agent.apply_proposal(conn, pid, OPERATOR)
        return {"ok": ok}
    except agent.GateError as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=409)
    finally:
        conn.close()


@app.post("/api/simulate/blank/{host}")
def api_blank(host: str):
    conn = db.connect()
    db.blank_live_l3(conn, host)
    conn.close()
    return {"ok": True}


@app.post("/api/reset")
def api_reset():
    conn = db.connect()
    # The audit trail is append-only, so reset keeps it and records itself.
    conn.executescript("DELETE FROM findings; DELETE FROM proposals; DELETE FROM live;")
    conn.commit()
    db.add_audit(conn, OPERATOR, "reset", None, "demo state cleared; audit trail kept")
    db.seed_live_match(conn)
    conn.close()
    return {"ok": True}
