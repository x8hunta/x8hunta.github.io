# NAL-001 verification (W3), 2026-11-05

**Checker 1: Claude (builder).** All 13 slides rendered with Edge at 1280x720 and inspected. Fixed: slide 2 uplink line not drawn, slide 5 evidence overflowing the footer, slide 11 commands split from their text. No overflow after fixes.

**Checker 2: gemma4:31b-cloud** via the local Ollama API (text only, no tools, temperature 0). Input: `content.md` and the deck's extracted text. Raw output below. Took 8 s.

## Triage of gemma's output (checked by Claude against deck.html)
- **Section C (IPs, interfaces, VLANs, ping counts, commands, banner, handle): all correct.** Matches the builder's check.
- **Section B ("missing from deck"): 10 items, all false.** Each one is in deck.html (grep count 1 each). Cause: the text extraction ran labels into values (e.g. `CLASSINTERNAL`), and gemma read those as missing. Its own section C says the banner is present, which contradicts its section B.
- **Section A: noise and two real items.**
  - Noise: footer chrome flagged NEW-CLAIM on every slide; status tags (Cleared, Done, Passed) flagged NEW-CLAIM although they restate approved items; slide 13 "CHANGED" is the same sentence split by a tag.
  - Real: text not in the approved wording, all derived from approved facts, needing operator approval:
    1. Slide 02 heading "Five assets, one subnet" (2 switches + 3 hosts, one /24).
    2. Slide 02 diagram label "VLAN 10 must cross tagged" (restates approved slide 04: "two ends disagree on tagging").
    3. New slide headings: "Incoming ticket", "Uplink mismatch", "Isolating Host B", "Host B online", "Three records, no reconciliation", "Prove it on the device", "Entry status".
    4. Image alt text and evidence captions (describe the screenshots).

**Verdict on gemma as verifier:** fast and caught the additions, but noisy, and its "missing" section was wrong. Useful as a second pass whose output is itself checked. Not an authority, and not an independent reviewer.

## Raw gemma output
A.
- Slide 01, "NAL-001 · Net Asset Lab", HEADING
- Slide 01, "Log entry · Network asset governance", HEADING
- Slide 01, "The Trunk That Wasn't", HEADING
- Slide 01, "DATE2026-11-05", HEADING
- Slide 01, "ASSETSW1 to SW2 uplink, Host B", HEADING
- Slide 01, "CLASSINTERNAL", HEADING
- Slide 01, "_x8hunta · ShadowOpsNet-Asset-Writeups", NEW-CLAIM
- Slide 02, "NAL-001 · Topology", HEADING
- Slide 02, "Five assets, one subnet", NEW-CLAIM
- Slide 02, "Gi0/4 · UPLINK · Gi0/4", HEADING
- Slide 02, "VLAN 10 must cross tagged", NEW-CLAIM
- Slide 02, "SW1", HEADING
- Slide 02, "SW2", HEADING
- Slide 02, "Gi0/1", HEADING
- Slide 02, "Gi0/2", HEADING
- Slide 02, "Gi0/0", HEADING
- Slide 02, "HOST A", HEADING
- Slide 02, "HOST B", HEADING
- Slide 02, "HOST C", HEADING
- Slide 02, "182.168.1.4 (diagram)", HEADING
- Slide 02, "192.168.1.4 (device)", HEADING
- Slide 02, "ALL HOSTS · VLAN 10 · 192.168.1.0/24", HEADING
- Slide 02, "Record vs reality", HEADING
- Slide 02, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 03, "NAL-001 · I. The Challenge", HEADING
- Slide 03, "I. The challenge", HEADING
- Slide 03, "Incoming ticket", HEADING
- Slide 03, "Ticket", HEADING
- Slide 03, "Impact severity", HEADING
- Slide 03, "MEDIUM", HEADING
- Slide 03, "Risk vector", HEADING
- Slide 03, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 04, "NAL-001 · II. Technician's View", HEADING
- Slide 04, "II. Technician's view · Fault 1", HEADING
- Slide 04, "Uplink mismatch", HEADING
- Slide 04, "[image alt: SW1 show interfaces status: Gi0/4 connected, trunk]", ALT-TEXT
- Slide 04, "Ev 01 · SW1 Gi0/4 trunk", HEADING
- Slide 04, "[image alt: SW2 show interfaces status: Gi0/4 connected, trunk]", ALT-TEXT
- Slide 04, "Ev 02 · SW2 Gi0/4 trunk", HEADING
- Slide 04, "[image alt: Ping to 192.168.1.4, 4 of 4 replies]", ALT-TEXT
- Slide 04, "Ev 03 · A to C 4/4 · no host name", HEADING
- Slide 04, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 05, "NAL-001 · II. Technician's View", HEADING
- Slide 05, "II. Technician's view · Fault 2", HEADING
- Slide 05, "Isolating Host B", HEADING
- Slide 05, "Trunk (A to C works over it)Cleared", NEW-CLAIM
- Slide 05, "VLAN 10 on both switchesCleared", NEW-CLAIM
- Slide 05, "Host CCleared", NEW-CLAIM
- Slide 05, "SW1 Gi0/2, B's port (connected, VLAN 10)Cleared", NEW-CLAIM
- Slide 05, "Host BRemaining suspect", NEW-CLAIM
- Slide 05, "Evidence before the fix", HEADING
- Slide 05, "[image alt: Host B ipconfig: no IPv4 address or subnet mask]", ALT-TEXT
- Slide 05, "Ev 04 · B has no IPv4 address or mask", HEADING
- Slide 05, "[image alt: Host C ping to 192.168.1.3: 4 sent, 0 received]", ALT-TEXT
- Slide 05, "Ev 05 · C to B 0/4", HEADING
- Slide 05, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 06, "NAL-001 · Near miss", HEADING
- Slide 06, "The near miss", HEADING
- Slide 06, "The form that lied", HEADING
- Slide 06, "[image alt: Host B settings panel with grey placeholder values 192.0.2.10 and 192.0.2.1]", ALT-TEXT
- Slide 06, "Ev 07 · placeholders, not values", HEADING
- Slide 06, "[image alt: Host B ipconfig still showing no address]", ALT-TEXT
- Slide 06, "Ev 06 · B unchanged", HEADING
- Slide 06, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 07, "NAL-001 · Fix verified", HEADING
- Slide 07, "Fix verified", HEADING
- Slide 07, "Host B online", HEADING
- Slide 07, "Host B · static", HEADING
- Slide 07, "192.168.1.3", HEADING
- Slide 07, "255.255.255.0", HEADING
- Slide 07, "gateway: blank", HEADING
- Slide 07, "Why the gateway is blank", HEADING
- Slide 07, "[image alt: Host B ipconfig: 192.168.1.3, 255.255.255.0]", ALT-TEXT
- Slide 07, "Ev 08 · B after", HEADING
- Slide 07, "[image alt: Host C ping to 192.168.1.3: 4 of 4 replies]", ALT-TEXT
- Slide 07, "Ev 09 · C to B 4/4", HEADING
- Slide 07, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 08, "NAL-001 · III. Architect's View", HEADING
- Slide 08, "III. Architect's view", HEADING
- Slide 08, "Three records, no reconciliation", HEADING
- Slide 08, "Inference Framed as \"if this were a production network.\"", HEADING
- Slide 08, "Record 1", HEADING
- Slide 08, "Diagram", HEADING
- Slide 08, "Record 2", HEADING
- Slide 08, "Interface descriptions", HEADING
- Slide 08, "Record 3", HEADING
- Slide 08, "Device configs", HEADING
- Slide 08, "Root cause", HEADING
- Slide 08, "Governance gap", HEADING
- Slide 08, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 09, "NAL-001 · Findings", HEADING
- Slide 09, "Architect's view", HEADING
- Slide 09, "Five findings", HEADING
- Slide 09, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 10, "NAL-001 · IV. Remediation and Control", HEADING
- Slide 10, "IV. Remediation and control", HEADING
- Slide 10, "Control NCV-1 · Network Change Verification", HEADING
- Slide 10, "Immediate SW2 Gi0/4 set to trunk. Host B given a static address.", HEADING
- Slide 10, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 11, "NAL-001 · Verification Protocol", HEADING
- Slide 11, "Verification protocol", HEADING
- Slide 11, "Prove it on the device", HEADING
- Slide 11, "This rep", HEADING
- Slide 11, "sh int status on both endsDone", NEW-CLAIM
- Slide 11, "show run int g0/4 on both endsDone", NEW-CLAIM
- Slide 11, "ipconfig before and after on BDone", NEW-CLAIM
- Slide 11, "A ping on each pathDone", NEW-CLAIM
- Slide 11, "The lab checkerPassed", NEW-CLAIM
- Slide 11, "Monitoring NCV-1", HEADING
- Slide 11, "Planned, not built", HEADING
- Slide 11, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 12, "NAL-001 · The bridge", HEADING
- Slide 12, "Network practice to asset governance", HEADING
- Slide 12, "The bridge", HEADING
- Slide 12, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 13, "NAL-001 · Audit Trail", HEADING
- Slide 13, "Audit trail", HEADING
- Slide 13, "Entry status", HEADING
- Slide 13, "Field | Value |", HEADING
- Slide 13, "Verified by | The operator (self) and the automated lab checker. No independent reviewer", CHANGED
- Slide 13, "Self-verification is noted as a limit. |", NEW-CLAIM
- Slide 13, "Status | Resolved (lab) |", HEADING
- Slide 13, "Open | The description naming mismatch, noted and not changed. |", HEADING
- Slide 13, "Sources | ~/shadowops/lab/2026-10-23-witty-1.3.md, screenshots 01 to 12. |", HEADING
- Slide 13, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM

B.
- "Classification: INTERNAL" (Slide 01)
- "Banner: TRAINING LAB EXERCISE. SIMULATED NETWORK. NOT CLIENT WORK." (Slide 01)
- "Topology: SW1 (A on Gi0/1, B on Gi0/2), SW2 (C on Gi0/0), SW1 Gi0/4 to SW2 Gi0/4. All hosts in VLAN 10, 192.168.1.0/24." (Slide 02)
- "Impact severity: Medium." (Slide 03)
- "Evidence: screenshots 01 and 02 (both ends trunk) and 03 (A to C, 4/4)." (Slide 04)
- "Ruled out: trunk (A to C works over it), VLAN 10 on both switches, Host C, SW1 Gi0/2 (connected, VLAN 10). Remaining suspect: Host B." (Slide 05)
- "Evidence before the fix: screenshot 04 (B has no IPv4 address or mask) and 05 (C to B, 0/4)." (Slide 05)
- "Evidence: screenshots 07 and 06." (Slide 06)
- "Evidence: screenshot 08 (B after) and 09 (C to B, 4/4)." (Slide 07)
- "Verified by: the operator (self) and the automated lab checker. No independent reviewer. Self-verification is noted as a limit." (Slide 13)

C.
- IP addresses: Correct.
- Interface names: Correct.
- VLAN numbers: Correct.
- Ping counts: Correct.
- Command syntax: Correct.
- Training-lab banner: Present.
- Handle "_x8hunta": Present.