# NAL-001 · "The Trunk That Wasn't": approved deck text
Approved 2026-11-05 (W1). Source: `~/shadowops/lab/2026-10-23-witty-1.3.md`, screenshots `~/shadowops/lab/2026-10-23-witty-1.3/01` to `12`.

**01 · Title**
LOG ENTRY NAL-001 · "The Trunk That Wasn't"
Witty Networks: Troubleshooting Fundamentals 1.3
2026-11-05 · Asset: SW1 to SW2 uplink, Host B · Classification: INTERNAL
Banner: TRAINING LAB EXERCISE. SIMULATED NETWORK. NOT CLIENT WORK.

**02 · The network as an asset set**
Topology: SW1 (A on Gi0/1, B on Gi0/2), SW2 (C on Gi0/0), SW1 Gi0/4 to SW2 Gi0/4. All hosts in VLAN 10, 192.168.1.0/24.
Callout: the diagram listed Host C as 182.168.1.4. The device was 192.168.1.4. The record was wrong before work started.

**03 · I. The Challenge**
Ticket: Host C cannot reach Hosts A and B.
- Impact severity: Medium. One host was cut off from both peers. No data loss.
- Risk vector: configuration drift, and records that diverged from the devices.

**04 · II. Technician's View: Fault 1, uplink mismatch**
- SW1 Gi0/4: trunk, description `Trunk_to_SW2`. SW2 Gi0/4: access port.
- VLAN 10 frames can't cross a link whose two ends disagree on tagging.
- Fix, reviewed before typing: at `SW2(config-if)#`, `switchport mode trunk`.
- Evidence: screenshots 01 and 02 (both ends trunk) and 03 (A to C, 4/4).
- Note: the "before" state for SW2 comes from the 10-22 record. No screenshot exists.

**05 · II. Technician's View: Fault 2, isolating Host B**
Ruled out: trunk (A to C works over it), VLAN 10 on both switches, Host C, SW1 Gi0/2 (connected, VLAN 10). Remaining suspect: Host B.
Evidence before the fix: screenshot 04 (B has no IPv4 address or mask) and 05 (C to B, 0/4).

**06 · The near miss: the form that lied**
The first fix didn't take. The settings panel showed grey placeholder text (192.0.2.x) that read as saved values. `ipconfig` showed nothing had changed.
Evidence: screenshots 07 and 06.
Line: A form that looks filled in is not proof that anything was saved. The device's output is.

**07 · Fix verified**
Host B: static 192.168.1.3 / 255.255.255.0, gateway blank.
Evidence: screenshot 08 (B after) and 09 (C to B, 4/4).
Why the gateway is blank: no router exists, and all hosts share one subnet. A gateway of .1 would have passed the ping while naming a device that doesn't exist.

**08 · III. Architect's View** (inference, framed as "if this were a production network")
- Root cause: three records described this network: the diagram, the interface descriptions and the device configs. Nothing reconciled them, so each fault was a gap between a record and reality.
- Governance gap: there was no step that checked a device against its design record after a change, and no check that a device had been configured before it went into service.

**09 · Five findings**
| # | Finding | Pillar | Lifecycle | Doctrine |
|---|---|---|---|---|
| 1 | Diagram vs device on C's address | Metadata | Operate | Reality wins; the record is the finding |
| 2 | Placeholder text read as saved config | Metadata | Maintain | Evidence over assertion |
| 3 | Gateway to a device that doesn't exist (proposed, caught at review) | Metadata | Maintain | Ghost record |
| 4 | SW2 drifted from the design in SW1's description; the two ends use different description formats | Metadata | Operate | Configuration drift |
| 5 | The lab checker passed the outcome without checking the config | Assurance | Maintain | Performative compliance |

**10 · IV. Remediation and Control**
Immediate: SW2 Gi0/4 set to trunk. Host B given a static address.
Control NCV-1: Network Change Verification
1. Every change is written out with its prompt and reviewed before it is typed.
2. Before and after evidence comes from the device itself, with the device name visible. Forms and diagrams don't count.
3. After a change, both ends of a link are checked against the design record (`show run int`).
4. Every value in a config must name something that exists: an address, a VLAN, a gateway.
5. Any gap between record and device is logged as a finding. The record is corrected, unless the device breaks the design.

**11 · Verification Protocol**
This rep: `sh int status` on both ends, `show run int g0/4` on both ends, `ipconfig` before and after on B, a ping on each path, then the lab checker.
Monitoring NCV-1: a scheduled export of device config, compared against the register and diagram. Any mismatch is a finding.
Planned, not built: NAE (Net-Asset-Extractor) reads a diagram into a register, which gives that comparison its baseline.

**12 · The bridge: network practice to asset governance**
| Network practice | Asset governance equivalent |
|---|---|
| Network diagram | The asset register |
| Interface description | Metadata that records design intent |
| `show run` / `ipconfig` | Inspecting the asset itself, the physical truth |
| Unsaved form field | A record entry with no evidence behind it |
| Lab checker | An outcome test, not a config audit |

**13 · Audit Trail**
- Verified by: the operator (self) and the automated lab checker. No independent reviewer. Self-verification is noted as a limit.
- Entry status: RESOLVED (lab). Open: the description naming mismatch, noted and not changed.
- Sources: `~/shadowops/lab/2026-10-23-witty-1.3.md`, screenshots 01 to 12.

## Build additions approved 2026-11-05
Wording added during the build, approved by the operator after review:
- Slide 02 heading "Five assets, one subnet"; diagram label "Both ends must be trunks" (replaced "VLAN 10 must cross tagged", which he found confusing).
- Slide headings: "Incoming ticket", "Uplink mismatch", "Isolating Host B", "Host B online", "Three records, no reconciliation", "Prove it on the device", "Entry status".
