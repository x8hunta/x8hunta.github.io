# NAL-003 verification

Build: `python3 build.py Labs/NAL-003-witty-1.5/deck.html` → `NAL-003-witty-1.5.html`, 871 KB.

## Structural checks (automated)
- 12 slides present (`<section class="slide">` ×12), matches content.md 01–12.
- 6 screenshots embedded as base64 data URIs; 0 unresolved `.png` src remain.
- theme.css and deck.js inlined (1 `<style>`, 1 `<script>`); 0 external `<link>`/`<script src>` remain.
- HTML parses clean.

## Claim-to-source traceability
Every slide claim traces to `~/shadowops/lab/2026-11-06-witty-1.5.md`:
- Host_D complete / Host_B blank → Ev 03, 02.
- Split test A→D 4/4 TTL 127, R1 path proven → Ev 05.
- Fix 192.168.1.3 /29 gw .1.1, both-ends 4/4, checker passed → Ev 08, 09, 10.
- Architect's View (no register, address read from a peer) → lab record root cause + his X0 answer.
- Control AAR-1 → his X0 answer (IPAM register + scheduled reconciliation; DHCP snooping / DAI for the forged-gateway case).

## Screenshots used vs captured
Used on slides: 02, 03, 05, 08, 09, 10. Captured but not placed (narrative subset): 01 topology (shown as SVG), 04 Host_A ipconfig, 06 Host_B settings panel, 07 Host_B ipconfig after. All 10 remain in `~/shadowops/lab/2026-11-06-witty-1.5/`.

## Open
- Visual render / overflow check in Firefox is the operator's (same as NAL-001). Automated checks cover structure and references, not layout overflow.
- Entry is a training-lab exercise, labelled as such on every slide. Not client work.

---

## Second-AI verifier run (2026-11-08)

**Checker 2: gemma4:31b-cloud** via local Ollama API (text only, no tools, temperature 0). Input: content.md + deck.html text, extracted the same naive way as NAL-001 (tags stripped, no separators). 7.5 s. Prompt: below (rebuilt from NAL-001's output format; the NAL-001 prompt was not saved).

### Triage (checked by Claude against content.md, deck.html, lab record and screenshot 01)
- **C (facts): 6 of 8 correct.** IPs, masks, gateways, ping counts, commands, banner all correct.
  - Interfaces "WRONG": half right. Gi0/2 and Gi0/3 are in the deck diagram but not in content.md or the lab record. Screenshot 01 shows the values are correct (SW2 Gi0/3 Host_D, Gi0/2 Host_C; SW1 Gi0/1 Host_A, Gi0/2 Host_B, Gi0/3 R1). Real finding: the labels trace only to a screenshot, not to approved text.
  - Handle "NEW-CLAIM": theme footer, same noise as NAL-001.
- **B (missing): 9 items. 5 false, 1 by design, 3 real.**
  - False (in deck, split by extraction): title, Witty 1.5 line, Classification/INTERNAL, evidence refs [02] [03] [05].
  - By design: screenshot [01] drawn as SVG; [06] [07] not placed (noted in verification.md).
  - Real: the "first routed lab ... unlike 1.3/1.4, blank was correct" callout was reworded and its comparison dropped; "unprompted" dropped; reverse-ping evidence list shortened.
- **A (unapproved text): ~105 lines, mostly noise** (headings, footer on every slide, run-together labels such as "The HostOff the Books").
  - Real: wording not in content.md, derived from approved facts, never approved: "The network as an asset set", "The gap / And no record said what Host_B should be.", "Host_B fixed: 192.168.1.3 · gw 192.168.1.1", tags "Routed path healthy", "R1 confirmed", "R1 bottom proven", "Sole suspect", "Read, not guessed".

### Verdict
Same pattern as NAL-001. Facts: reliable. "Missing" list: mostly false, caused by the text extraction. Unapproved-wording list: noisy, but it found real additions both times. One new kind of catch this run: a correct value with no text source (ports). Still a second pass whose output must be checked.

### Across both runs
| | NAL-001 | NAL-003 |
|---|---|---|
| Fact checks correct | all | 6/8 (1 half-right, 1 noise) |
| "Missing" items false | 10/10 | 5/9 (+1 by design) |
| Real unapproved wording found | yes | yes (~9 lines) |

**Correction to the traceability section above:** facts trace to the lab record, but about 9 lines of deck wording were never in the approved content.md (listed under A). Status changed to wording review pending.

### Prompt (instructions; the full call also embeds content.md and the extracted deck text)
```
Answer in three sections:
A. Every text item in the deck that is not word-for-word in the approved source. One line each: - Slide NN, "text", TAG  where TAG is HEADING, NEW-CLAIM or CHANGED.
B. Every item in the approved source that is missing from the deck. One line each.
C. Check these facts match between source and deck: IP addresses, subnet masks, gateways, interfaces, ping counts, commands, the training-lab banner, the author handle. One line each: fact, CORRECT or WRONG, and why if wrong.```

### Raw gemma output

A.
- Slide 01, "NAL-003 · Net Asset Lab", HEADING
- Slide 01, "Log entry · Network asset governance", HEADING
- Slide 01, "The HostOff the Books", HEADING
- Slide 01, "DATE2026-11-06", CHANGED
- Slide 01, "ASSETHost_B · 192.168.1.0/29", CHANGED
- Slide 01, "CLASSINTERNAL", CHANGED
- Slide 01, "_x8hunta · ShadowOpsNet-Asset-Writeups", NEW-CLAIM
- Slide 02, "NAL-003 · Topology", HEADING
- Slide 02, "The network as an asset set", HEADING
- Slide 02, "TOP · 192.168.2.0/29", CHANGED
- Slide 02, "Gi0/3", NEW-CLAIM
- Slide 02, "Gi0/2", NEW-CLAIM
- Slide 02, "HOST D", CHANGED
- Slide 02, "HOST C", CHANGED
- Slide 02, "Gi0/1 · Gi0/0", CHANGED
- Slide 02, "Gi0/1 · Gi0/3", NEW-CLAIM
- Slide 02, "Gi0/1", NEW-CLAIM
- Slide 02, "Gi0/2", NEW-CLAIM
- Slide 02, "HOST A", CHANGED
- Slide 02, "HOST B", CHANGED
- Slide 02, "BOTTOM · 192.168.1.0/29", CHANGED
- Slide 02, "Host_B fixed: 192.168.1.3 · gw 192.168.1.1", NEW-CLAIM
- Slide 02, "The gap", HEADING
- Slide 02, "And no record said what Host_B should be.", NEW-CLAIM
- Slide 02, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 03, "NAL-003 · I. The Challenge", HEADING
- Slide 03, "I. The challenge", HEADING
- Slide 03, "Incoming ticket", HEADING
- Slide 03, "Ticket", HEADING
- Slide 03, "Impact severity", HEADING
- Slide 03, "Risk vector", HEADING
- Slide 03, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 04, "NAL-003 · II. Technician's View", HEADING
- Slide 04, "II. Technician's view · Reading the hosts", HEADING
- Slide 04, "Two hosts, one blank", HEADING
- Slide 04, "Rule-out A host with no identity can't reach anyone, and nothing tested from it is trustworthy.", CHANGED
- Slide 04, "Ev 03 · Host_D complete", CHANGED
- Slide 04, "Ev 02 · Host_B blank", CHANGED
- Slide 04, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 05, "NAL-003 · II. Technician's View", HEADING
- Slide 05, "II. Technician's view · The split test", HEADING
- Slide 05, "Is it only Host_B?", HEADING
- Slide 05, "Test from known-good Host_A (same subnet as B) across both subnets.", CHANGED
- Slide 05, "Routed path healthy", NEW-CLAIM
- Slide 05, "R1 confirmed", NEW-CLAIM
- Slide 05, "R1 bottom proven", NEW-CLAIM
- Slide 05, "Sole suspect", NEW-CLAIM
- Slide 05, "Ev 05 · A to D 4/4 · TTL 127", CHANGED
- Slide 05, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 06, "NAL-003 · Fix verified", HEADING
- Slide 06, "Fix verified", HEADING
- Slide 06, "Host_B online", HEADING
- Slide 06, "Host_B · static", HEADING
- Slide 06, "192.168.1.3255.255.255.248gw 192.168.1.1", CHANGED
- Slide 06, "Read, not guessed", HEADING
- Slide 06, "Ev 08 · D to B 4/4", CHANGED
- Slide 06, "Ev 09 · B to D 4/4", CHANGED
- Slide 06, "Ev 10 · Checker passed", CHANGED
- Slide 06, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 07, "NAL-003 · III. Architect's View", HEADING
- Slide 07, "III. Architect's view", HEADING
- Slide 07, "No record to check against", HEADING
- Slide 07, "Inference Framed as \"if this were a production network.\"", CHANGED
- Slide 07, "Root cause", HEADING
- Slide 07, "Governance gap", HEADING
- Slide 07, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 08, "NAL-003 · Findings", HEADING
- Slide 08, "Architect's view", HEADING
- Slide 08, "Five findings", HEADING
- Slide 08, "#FindingPillarLifecycleDoctrine", CHANGED
- Slide 08, "01Host in service with no L3 identity; nothing caught itMetadataOperateReality wins; the record is the finding", CHANGED
- Slide 08, "02No addressing register; correct value knowable only from a peerMetadataPlanIf it isn't documented, it didn't happen", CHANGED
- Slide 08, "03Blank gateway silently blocks cross-subnet reachMetadataOperateLine of sight: the asset can't leave its subnet", CHANGED
- Slide 08, "04Fault isolated from a known-good peer, not a single hostAssuranceMaintainTriangulation over trust", CHANGED
- Slide 08, "05The same gateway field is an interception surface ATT&CK T1557Legal & AccessOperateDetection pairs with prevention", CHANGED
- Slide 08, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 09, "NAL-003 · IV. Remediation and Control", HEADING
- Slide 09, "IV. Remediation and control", HEADING
- Slide 09, "Control AAR-1 · Address Authority & Reconciliation", HEADING
- Slide 09, "Immediate Host_B given its static address, mask and gateway from the subnet scheme.", CHANGED
- Slide 09, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 10, "NAL-003 · Verification Protocol", HEADING
- Slide 10, "Verification protocol", HEADING
- Slide 10, "Prove it on the host", HEADING
- Slide 10, "This rep", HEADING
- Slide 10, "ipconfig on D, B and ADone", CHANGED
- Slide 10, "Split-test ping from known-good ADone", CHANGED
- Slide 10, "ipconfig on B after the changeDone", CHANGED
- Slide 10, "Both-direction pingsDone", CHANGED
- Slide 10, "The lab checkerPassed", CHANGED
- Slide 10, "Monitoring AAR-1", HEADING
- Slide 10, "Planned, not built", HEADING
- Slide 10, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 11, "NAL-003 · The bridge", HEADING
- Slide 11, "Network practice to asset governance", HEADING
- Slide 11, "The bridge", HEADING
- Slide 11, "Network practiceAsset governance equivalent", CHANGED
- Slide 11, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM
- Slide 12, "NAL-003 · Audit Trail", HEADING
- Slide 12, "Audit trail", HEADING
- Slide 12, "Entry status", HEADING
- Slide 12, "FieldValue", NEW-CLAIM
- Slide 12, "Verified byThe operator (self) and the automated lab checker. No independent reviewerSelf-verification is noted as a limit.", CHANGED
- Slide 12, "StatusResolved (lab)", CHANGED
- Slide 12, "OpenNo IPAM register exists; AAR-1 is proposed, not built.", CHANGED
- Slide 12, "_x8hunta · ShadowOpsTraining lab · simulated", NEW-CLAIM

B.
- Slide 01, "LOG ENTRY NAL-003 · \"The Host Off the Books\""
- Slide 01, "Witty Networks: Troubleshooting Fundamentals 1.5"
- Slide 01, "2026-11-06 · Asset: Host_B, bottom subnet 192.168.1.0/29 · Classification: INTERNAL"
- Slide 02, "Topology: top 192.168.2.0/29 (Host_D .3, Host_C .2 on SW2); bottom 192.168.1.0/29 (Host_A .2, Host_B .3 on SW1); R1 routes between them (Gi0/0 to SW2, Gi0/1 to SW1). Screenshot [01]."
- Slide 02, "Callout: first routed lab in the series. Crossing a subnet now requires a default gateway — unlike 1.3/1.4, where blank was correct."
- Slide 04, "Evidence: screenshots [03], [02]."
- Slide 05, "Evidence: screenshot [05]."
- Slide 06, "Reproduced the ticket: Host_D ping Host_B 4/4; reverse 4/4 (unprompted). Checker: \"Network state verified.\""
- Slide 06, "Evidence: [06], [07], [08], [09], [10]."

C.
- IP addresses, CORRECT
- Subnet masks, CORRECT
- Gateways, CORRECT
- Interfaces, WRONG (Deck adds Gi0/3, Gi0/2; Source only lists Gi0/0, Gi0/1)
- Ping counts, CORRECT
- Commands, CORRECT
- Training-lab banner, CORRECT
- Author handle, NEW-CLAIM (Not in source)
