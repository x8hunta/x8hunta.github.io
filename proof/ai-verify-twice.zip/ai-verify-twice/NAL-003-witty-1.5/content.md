# NAL-003 · "The Host Off the Books": approved deck text
Approved 2026-11-06. Source: `~/shadowops/lab/2026-11-06-witty-1.5.md`, screenshots `~/shadowops/lab/2026-11-06-witty-1.5/01` to `10`. Training-lab exercise.

**01 · Title**
LOG ENTRY NAL-003 · "The Host Off the Books"
Witty Networks: Troubleshooting Fundamentals 1.5
2026-11-06 · Asset: Host_B, bottom subnet 192.168.1.0/29 · Classification: INTERNAL
Banner: TRAINING LAB EXERCISE. SIMULATED NETWORK. NOT CLIENT WORK.

**02 · Two subnets, one router**
Topology: top 192.168.2.0/29 (Host_D .3, Host_C .2 on SW2); bottom 192.168.1.0/29 (Host_A .2, Host_B .3 on SW1); R1 routes between them (Gi0/0 to SW2, Gi0/1 to SW1). Screenshot [01].
Callout: first routed lab in the series. Crossing a subnet now requires a default gateway — unlike 1.3/1.4, where blank was correct.

**03 · I. The Challenge**
Ticket: Host_D cannot communicate with Host_B.
- Impact severity: Medium. One host unreachable across the estate. No data loss.
- Risk vector: operational oversight — an asset in service without its network identity, and no record to catch it.

**04 · II. Technician's View: reading the two hosts**
- ipconfig Host_D: 192.168.2.3, /29, gw 192.168.2.1 — complete.
- ipconfig Host_B: no address, no mask, no gateway — no L3 identity.
- Rule-out: a host with no identity can't reach anyone, and nothing tested from it is trustworthy.
- Evidence: screenshots [03], [02].

**05 · II. Technician's View: the split test**
Is it only Host_B, or is R1's path also broken? Test from known-good Host_A (same subnet as B).
- Host_A ping Host_D: 4/4, TTL 127. The routed path is healthy; TTL 127 = exactly one router hop.
- Host_A's gateway (192.168.1.1) is Host_B's future gateway, so R1's bottom interface is already proven good.
- Fault isolated to Host_B. Evidence: screenshot [05].

**06 · II. Technician's View: the fix, proven**
- Host_B static, reviewed before typing: 192.168.1.3 / 255.255.255.248 (/29) / gw 192.168.1.1 — values read off subnet-mate Host_A, not guessed.
- Self-verified config with ipconfig before the outcome test.
- Reproduced the ticket: Host_D ping Host_B 4/4; reverse 4/4 (unprompted). Checker: "Network state verified."
- No save step: a host has no running/startup split. Evidence: [06], [07], [08], [09], [10].

**07 · III. Architect's View** (inference, framed as "if this were a production network")
- Root cause: the correct address for Host_B existed nowhere as a record. It was reconstructed by reading a neighbour. The asset was off the books.
- Governance gap: no authoritative addressing register, and no step that checks a host's live config against an intended record before it goes into service or on a schedule after.

**08 · Five findings**
| # | Finding | Pillar | Lifecycle | Doctrine |
|---|---|---|---|---|
| 1 | Host in service with no L3 identity; nothing caught it | Metadata | Operate | Reality wins; the record is the finding |
| 2 | No addressing register; correct value knowable only from a peer | Metadata | Plan | If it isn't documented, it didn't happen |
| 3 | Blank gateway silently blocks cross-subnet reach | Metadata | Operate | Line of sight: the asset can't leave its subnet |
| 4 | Fault isolated from a known-good peer, not a single host | Assurance | Maintain | Triangulation over trust |
| 5 | The same gateway field is an interception surface (ATT&CK T1557) | Legal & Access | Operate | Detection pairs with prevention |

**09 · IV. Remediation and Control**
Immediate: Host_B given its static address, mask and gateway from the subnet scheme.
Control AAR-1: Address Authority & Reconciliation
1. Every host's intended address, mask and gateway lives in an IPAM register — the authoritative source of truth, not the diagram and not the device.
2. A host is not in service until its live config matches its register entry.
3. A scheduled scan reconciles live host config against the register; any divergence is a logged finding.
4. On divergence, reality is the finding: register or host is corrected under change control. The disagreement is never left standing.
5. Every gateway entry must name the real router interface. Rogue-gateway insertion (DHCP spoofing, ARP poisoning) is prevented with DHCP snooping and Dynamic ARP Inspection — and caught by the same scan.

**10 · Verification Protocol**
This rep: ipconfig on D, B and A; a split-test ping from known-good A; ipconfig on B after the change; both-direction pings; then the lab checker.
Monitoring AAR-1: scheduled reconciliation of a live scan against the IPAM register. Any mismatch is a finding.
Planned, not built: NAE (Net-Asset-Extractor) reads a diagram into a register, which gives that scan its baseline.

**11 · The bridge: network practice to asset governance**
| Network practice | Asset governance equivalent |
|---|---|
| IPAM / addressing scheme | The asset register (source of truth) |
| Default gateway | The asset's declared route to the wider estate |
| ipconfig / live scan | Inspecting the asset itself, the physical truth |
| Reading the peer to learn B's address | Rebuilding a record from a neighbour because none exists |
| "Network state verified" checker | An outcome test, not a register audit |

**12 · Audit Trail**
- Verified by: the operator (self) and the automated lab checker. No independent reviewer; self-verification noted as a limit.
- Entry status: RESOLVED (lab). Open: no IPAM register exists; AAR-1 is proposed, not built.
- Sources: `~/shadowops/lab/2026-11-06-witty-1.5.md`, screenshots 01 to 10.
