# Proof bundle: Working with AI taught me to verify twice

Label: TRAINING LAB. The decks are write-ups of network troubleshooting labs. Not client work.
Source: private repo, commit b9b0f1c66173873b17bea266b110fa383486e15e (tag proof-rel-001). Built 2026-11-08.

## Which file backs each claim
| Claim | File |
|---|---|
| Run 1: facts right, all 10 "missing" items false, real unapproved wording found | NAL-001-witty-1.3/verification.md |
| Run 2: facts right, 5 of 9 "missing" false, ~9 unapproved lines found | NAL-003-witty-1.5/verification.md ("Second-AI verifier run") |
| What "approved text" means | each folder's content.md |

## What this doesn't prove
- Two runs, two decks, one model (gemma4:31b-cloud). A pattern to watch, not a measured result.
- The run 1 prompt was not saved; run 2's prompt is in its verification.md.
- Claude built the decks and triaged both runs.

The slide decks themselves are not included: they contain screenshots of a third-party lab platform.

## Check this bundle
`sha256sum -c FILES.sha256` inside this folder.
